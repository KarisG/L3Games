module(...)

function getSequenceData()
    local sequenceData = {
        {
            name = "idle",
            frames = {1},
            time = 1000,
            loopCount = 1
        },
        {
            name = "press-up",
            frames={2},
            time = 1000,
            loopCount = 1
        },
        {
            name = "press-down",
            frames={3},
            time = 1000,
            loopCount = 1
        },
        {
            name = "press-left",
            frames={4},
            time = 1000,
            loopCount = 1
        },
        {
            name = "press-right",
            frames={5},
            time = 1000,
            loopCount = 1
        }
    }
    return sequenceData
end