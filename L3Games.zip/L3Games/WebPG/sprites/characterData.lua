module(...)

function getSpriteSheetData()
    local options = {
        -- Array of tables representing each frame (required)
        frames = {
            --FRAME Down 1
            {
                x = 0,
                y = 0,
                width = 64,
                height = 64
            },
            --FRAME Down 2
            {
                x = 64,
                y = 0,
                width = 64,
                height = 64
            },
            --FRAME Left 1
            {
                x = 0,
                y = 64,
                width = 64,
                height = 64
            },
            --FRAME Left 2
            {
                x = 64,
                y = 64,
                width = 64,
                height = 64
            },
            --FRAME Right 1
            {
                x = 0,
                y = 128,
                width = 64,
                height = 64
            },
            --FRAME Right 2
            {
                x = 64,
                y = 128,
                width = 64,
                height = 64
            },
            --FRAME Up 1
            {
                x = 0,
                y = 192,
                width = 64,
                height = 64
            },
            --FRAME Up 2
            {
                x = 64,
                y = 192,
                width = 64,
                height = 64
            },
        },
        sheetContentWidth = 128,
        sheetContentHeight = 256
    }
    return options
end