module(...)

function getSequenceData()
    local sequenceData = {
        {
            name = "moving-down",
            frames={1, 2},
            time = 1000,
            loopCount = 0
        },
        {
            name = "moving-left",
            frames={3, 4},
            time = 1000,
            loopCount = 0
        },
        {
            name = "moving-right",
            frames={5, 6},
            time = 1000,
            loopCount = 0
        },
        {
            name = "moving-up",
            frames={7, 8},
            time = 1000,
            loopCount = 0
        }
    }
    return sequenceData
end