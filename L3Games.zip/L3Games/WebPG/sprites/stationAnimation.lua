module(...)

function getSequenceData()
    local sequenceData = {
        {
            name = "idle",
            frames={1, 2, 1, 3},
            time = 4000,
            loopCount = 0
        },
    }
    return sequenceData
end