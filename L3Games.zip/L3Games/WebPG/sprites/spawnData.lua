module(...)

function getSpriteSheetData()
    local options = {
        -- Array of tables representing each frame (required)
        frames = {
            --FRAME 1 - RED
            {
                x = 0,
                y = 0,
                width = 288,
                height = 288
            },
            --FRAME 2 - RED
            {
                x = 0,
                y = 288,
                width = 288,
                height = 288
            },
            --FRAME 3 - RED
            {
                x = 0,
                y = 576,
                width = 288,
                height = 288
            },
            --FRAME 4 - RED
            {
                x = 0,
                y = 864,
                width = 288,
                height = 288
            },
            --FRAME 5 - RED
            {
                x = 0,
                y = 1152,
                width = 288,
                height = 288
            },
            --FRAME 6 - RED
            {
                x = 0,
                y = 1440,
                width = 288,
                height = 288
            },
            --FRAME 7 - RED
            {
                x = 0,
                y = 1728,
                width = 288,
                height = 288
            },
            --FRAME 1 - GREEN
            {
                x = 288,
                y = 0,
                width = 288,
                height = 288
            },
            --FRAME 2 - GREEN
            {
                x = 288,
                y = 288,
                width = 288,
                height = 288
            },
            --FRAME 3 - GREEN
            {
                x = 288,
                y = 576,
                width = 288,
                height = 288
            },
            --FRAME 4 - GREEN
            {
                x = 288,
                y = 864,
                width = 288,
                height = 288
            },
            --FRAME 5 - GREEN
            {
                x = 288,
                y = 1152,
                width = 288,
                height = 288
            },
            --FRAME 6 - GREEN
            {
                x = 288,
                y = 1440,
                width = 288,
                height = 288
            },
            --FRAME 7 - GREEN
            {
                x = 288,
                y = 1728,
                width = 288,
                height = 288
            }
        },
        sheetContentWidth = 576,
        sheetContentHeight = 2016
    }
    return options
end