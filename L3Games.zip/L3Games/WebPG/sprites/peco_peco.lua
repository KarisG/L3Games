module(...)

function getSequenceData()
    local sequenceData = {
        -- consecutive frames sequence
        {
            name = "screen",
            start = 1,
            count = 22,
            time = 1830,
            loopCount = 1,
            loopDirection = "forward"
        }
    }
    return sequenceData
end

function getSpriteSheetData()
    local sheetOptions =
    {
        width = 572,
        height = 764,
        numFrames = 22
    }
    return sheetOptions
end