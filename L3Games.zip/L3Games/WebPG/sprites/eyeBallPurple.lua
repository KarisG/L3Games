module(...)

function getSequenceData()
    local sequenceData = {
        -- consecutive frames sequence
        {
            name = "float",
            start = 1,
            count = 8,
            time = 800,
            loopCount = 0,
            loopDirection = "forward"
        }
    }
    return sequenceData
end

function getSpriteSheetData()
    local sheetOptions =
    {
        width = 64,
        height = 64,
        numFrames = 8
    }
    return sheetOptions
end