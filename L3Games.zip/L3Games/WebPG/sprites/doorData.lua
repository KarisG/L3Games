module(...)

function getSpriteSheetData()
    local options = {
        -- Array of tables representing each frame (required)
        frames = {
            -- --- Blocked
            --FRAME 1
            {
                x = 0,
                y = 0,
                width = 128,
                height = 32
            },
            --FRAME 2
            {
                x = 0,
                y = 32,
                width = 128,
                height = 32
            },
            --FRAME 3
            {
                x = 0,
                y = 64,
                width = 128,
                height = 32
            },
            --FRAME 4
            {
                x = 0,
                y = 96,
                width = 128,
                height = 32
            },
            --FRAME 5
            {
                x = 0,
                y = 128,
                width = 128,
                height = 32
            },
            --FRAME 6
            {
                x = 0,
                y = 160,
                width = 128,
                height = 32
            },
            --FRAME 7
            {
                x = 0,
                y = 192,
                width = 128,
                height = 32
            },
            --FRAME 8
            {
                x = 0,
                y = 224,
                width = 128,
                height = 32
            }
        },
        sheetContentWidth = 128,
        sheetContentHeight = 256
    }
    return options
end