module(...)

function getSpriteSheetData()
    local options = {
        -- Array of tables representing each frame (required)
        frames = {
            --FRAME 1
            {
                x = 0,
                y = 0,
                width = 256,
                height = 128
            },
            --FRAME 2
            {
                x = 0,
                y = 128,
                width = 256,
                height = 128
            },
            --FRAME 3
            {
                x = 0,
                y = 256,
                width = 256,
                height = 128
            },
        },
        sheetContentWidth = 256,
        sheetContentHeight = 384
    }
    return options
end