module(...)

function getSpriteSheetData()
    local options = {
        -- Array of tables representing each frame (required)
        frames = {
            --FRAME Idle
            {
                x = 0,
                y = 0,
                width = 150,
                height = 150
            },
            --FRAME Top
            {
                x = 0,
                y = 150,
                width = 150,
                height = 150
            },
            --FRAME Bottom
            {
                x = 0,
                y = 300,
                width = 150,
                height = 150
            },
            --FRAME Left
            {
                x = 0,
                y = 450,
                width = 150,
                height = 150
            },
            --FRAME Right
            {
                x = 0,
                y = 600,
                width = 150,
                height = 150
            }
        },
        sheetContentWidth = 150,
        sheetContentHeight = 750
    }
    return options
end