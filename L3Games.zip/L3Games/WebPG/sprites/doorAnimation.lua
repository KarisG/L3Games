module(...)

function getSequenceData()
    local sequenceData = {
        {
            name = "blocked",
            frames={1, 2, 3, 4, 5, 6, 7, 8},
            time = 1600,
            loopCount = 0
        }
    }
    return sequenceData
end