module(...)

-- Tutorial level

function getMap()
    -- 12 * 20
    local map = {
        { 0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0 },   -- 1
        { 0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0 },   -- 2
        { 0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0 },   -- 3
        { 0,0,0,0,0,0,1,4,4,4,4,1,0,1,1,1,1,1,1,1 },   -- 4
        { 1,1,1,1,1,1,1,0,0,0,0,1,1,1,0,0,0,0,0,1 },   -- 5
        { 1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1 },   -- 6
        { 1,0,8,8,0,0,0,0,0,11,0,0,0,0,0,0,0,0,0,1 },   -- 7
        { 1,0,8,8,0,0,0,0,0,0,0,0,0,5,0,0,0,0,0,1 },   -- 8
        { 1,0,8,8,0,1,1,1,0,0,0,1,1,1,0,0,0,0,0,1 },   -- 9
        { 1,0,0,0,0,1,0,1,0,0,0,1,0,1,1,1,1,1,1,1 },   -- 10
        { 1,1,1,1,1,1,0,1,9,9,9,1,0,0,0,0,0,0,0,0 },   -- 11
        { 0,0,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0 },   -- 12
    }
    return map
end


function getCurrentLevel()
    return 2
end

function getSize(coord)
    if coord == "width" then
        return 384*2
    else
        return 640*2
    end
end

function mapSpawnPoint(coord)
    if coord == "x" then
        return -236
    else
        return -666
    end
end

function characterSpawnPoint(coord)
    if coord == "x" then
        return 180
    else
        return 390
    end
end

function getBackground()
    return "WebPG/assets/images/background2.png"
end

function getTasks()
    local taskList = {
        "Suivre les instructions du guide",
    }
    return taskList
end

function getGuideSpeech()
    local speech = {
        {
            "Salut petit drone!\nPour ce niveau, on\nva étudier le cas,",
            "d'un utilisateur qui\nveut accéder à une page\ndont il n'a pas accès.",
            "La requête de\nl'utilisateur se trouve\nun peu plus haut."
        },
        {
            "Encore une fois,\n bravo !",
            "Pour envoyer à\nl'utilisateur,",
            "il suffira de\nretourner au point\nde départ,",
            "ce qui terminera\nce niveau.",
            "On se retrouve\nau prochain niveau\npour étudier un\ncas plus sérieux !"
        }
    }
    return speech
end

function getBddSpeech()
    local speech = {
        {
            ""
        }
    }
    return speech
end

function getServerSpeech()
    local speech = {
        {
            "Identification :\ndrone joueur.",
            "Présentez moi votre\nrequête.",
            "...",
            "Vous n'avez aucune\nrequête.",
            "Veuillez me présenter\nune requête."
        },
        {
            "Identification :\ndrone joueur.",
            "Présentez moi votre\nrequête.",
            "...",
            "La requête :\naccéder à la page\n/profile.",
            "L'utilisateur n'est\npas connecté.",
            "Accès interdit.",
            "Rédaction de la\npage d'erreur 403...",
            "Veuillez aller\nchercher la page\nà l'imprimerie."
        }
    }
    return speech
end

function getPrintSpeech()
    local speech = {
        {
            "Votre fichier :\nProfile.vue est prêt.",
            "Vous pouvez l'envoyer\nà l'utilisateur pour lui\n afficher l'erreur 403.",
        }
    }
    return speech
end

function guideMovement(guide,map)
    local movement = { 
        { -- move 1
            {
                startTime = 0,
                tween = { guide,
                    { y = guide.y - 64 * 6},
                    {
                        time = 500 * 6,
                        onComplete = function()
                            guide.y = guide.y
                            map[148].value = 5
                        end,
                    }
                }
            },
        },
    }
    return movement
end

function getWinCondition()
    local win = { 11,12 }
    return win
end