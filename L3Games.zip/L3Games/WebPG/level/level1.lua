module(...)

-- Tutorial level

function getMap()
    -- 15 * 23
    local map = {
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0 },   -- 1
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0 },   -- 2
        {1,0,0,8,8,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0 },   -- 3
        {1,0,0,8,8,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0 },   -- 4
        {1,0,0,8,8,0,0,0,0,0,0,0,0,0,1,0,1,1,1,1,1,1,1 },   -- 5
        {1,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,0,0,0,0,0,1 },   -- 6
        {1,0,0,7,7,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1 },   -- 7
        {1,0,0,7,7,0,0,0,0,1,0,0,10,0,0,0,0,0,0,0,0,0,1 },  -- 8
        {1,0,0,7,7,0,0,0,0,1,0,0,0,0,0,0,5,0,0,0,0,0,1 },   -- 9
        {1,0,0,0,0,0,0,0,0,1,0,0,0,0,1,1,1,0,0,0,0,0,1 },   -- 10
        {1,0,0,0,0,0,0,0,0,1,2,2,2,2,1,0,1,1,1,1,1,1,1 },   -- 11
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0 },   -- 12
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0 },   -- 13
        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0 },   -- 14
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0 },   -- 15
    }
    return map
end

function getCurrentLevel()
    return 1
end

function getSize(coord)
    if coord == "width" then
        return 480*2
    else
        return 736*2
    end
end

function mapSpawnPoint(coord)
    if coord == "x" then
        return -300
    else
        return -858
    end
end

function characterSpawnPoint(coord)
    if coord == "x" then
        return 180
    else
        return 390
    end
end

function getBackground()
    return "WebPG/assets/images/background1.png"
end

function getTasks()
    local taskList = {
        "Suivre les instructions du guide",
    }
    return taskList
end

function getGuideSpeech()
    local speech = {
        {
            "Salut petit drone!\nJe serais ton guide\npour ce niveau.",
            "Pour commencer,\non va essayer d'ouvrir\nla porte au dessus.",
            "Pour l'ouvrir,\nil va falloir obtenir\nune carte d'accès !",
            "Il se trouve un peu\nplus haut."
        },
        {
            "Bravo, tu as réussi\nà ouvrir ta première\nporte !",
            "Maintenant, monte un\n peu plus haut pour\ninteragir avec la BDD."
        },
        {
            "Bien joué, tu as\npu interagir avec les\ndeux stations.",
            "C'est tout pour\nce niveau. Pour finir,\ntu dois retourner au\npoint de départ.",
            "On se retrouve\nau prochain niveau !"
        }
    }
    return speech
end

function getBddSpeech()
    local speech = {
        {
            "Identification :\ndrone joueur.",
            "Autorisation à\naccéder à la\nbase de données.",
            "Mon objectif :\nstocker les données\npersistantes.",
            "Vous aurez besoin\nde moi pour \nl'authentification.",
            "En cas de succès,\nje vous donnerais\nla carte d'accès à\ncertains fichier Vue." 
        }
    }
    return speech
end

function getServerSpeech()
    local speech = {
        {
            "Identification :\ndrone joueur.",
            "Autorisation à\naccéder au server.",
            "Mon objectif :\n- Envoyer les pages à\nl'utilisateur. Ces pages\nsont des fichiers Vue.",
            "- Recevoir,traiter et\nenvoyer des données à\nl'utilisateur.",
            "Je suis le pont entre\nla BDD et l'interface de\nl'utilisateur.",
            "En fonction des\ndonnées que vous\nme présenterez,",
            "je vous enverrai\nun fichier utile.",
            "Ce fichier servira\ndirectement l'utilisateur\nou d'autres fichiers." 
        }
    }
    return speech
end

function guideMovement(guide,map)
    local movement = { 
        { -- move 1
            {
                startTime = 0,
                tween = { guide,
                    { y = guide.y - 64 * 4},
                    {
                        time = 500 * 4,
                        onComplete = function()
                            guide.y = guide.y
                        end,
                    }
                }
            },
            {
                startTime = 500 * 4,
                tween = { guide,
                    { x = guide.x + 64 * 4},
                    {
                        time = 500 * 4,
                        onComplete = function()
                            guide.x = guide.x
                            map[289].value = 5
                        end,
                    }
                }
            },
        },
        { -- move 2
            {
                startTime = 0,
                tween = { guide,
                    { y = guide.y - 64 * 5},
                    {
                        time = 250 * 5,
                        onComplete = function()
                            guide.y = guide.y
                        end,
                    }
                }
            },
            {
                startTime = 250 * 5,
                tween = { guide,
                    { x = guide.x - 64 * 7},
                    {
                        time = 250 * 7,
                        onComplete = function()
                            guide.x = guide.x
                            map[123].value = 5
                        end,
                    }
                }
            },
        }
    }
    return movement
end

function getWinCondition()
    local win = { 7,8 }
    return win
end