module(...)

-- Tutorial level

function getMap()
    -- 15 * 18
    local map = {
        { 0,0,0,0,0,0,0,0,1,1,1,1,1,1,1 },    -- 1
        { 0,0,0,0,0,0,0,0,1,0,0,9,9,9,1 },    -- 2
        { 0,0,0,0,0,0,0,0,1,0,0,0,0,0,1 },    -- 3
        { 0,0,0,0,0,0,0,0,1,8,8,0,0,0,1 },    -- 4
        { 0,0,0,0,0,0,0,0,1,8,8,0,0,0,1 },    -- 5
        { 0,0,0,0,0,0,0,0,1,8,8,0,0,0,1 },    -- 6
        { 0,0,0,0,0,0,0,0,1,0,0,0,0,0,1 },    -- 7
        { 1,1,1,1,1,1,1,0,1,4,4,4,4,1,1 },    -- 8
        { 1,0,0,0,0,0,1,1,1,0,0,0,0,1,0 },    -- 9
        { 1,0,0,0,0,0,5,0,0,0,0,0,0,1,0 },    -- 10
        { 1,0,0,0,0,0,0,0,13,0,0,0,0,1,0 },    -- 11
        { 1,0,0,0,0,0,0,0,0,0,0,0,0,1,0 },    -- 12
        { 1,0,0,0,0,0,1,1,1,0,0,0,0,1,0 },    -- 13
        { 1,1,1,1,1,1,1,0,1,2,2,2,2,1,1 },    -- 14
        { 0,0,0,0,0,0,0,0,1,0,0,0,0,0,1 },    -- 15
        { 0,0,0,0,0,0,0,0,1,0,7,7,7,0,1 },    -- 16
        { 0,0,0,0,0,0,0,0,1,0,7,7,7,0,1 },    -- 17
        { 0,0,0,0,0,0,0,0,1,1,1,1,1,1,1 },    -- 18
    }
    return map
end


function getCurrentLevel()
    return 3
end

function getSize(coord)
    if coord == "width" then
        return 576*2
    else
        return 480*2
    end
end

function mapSpawnPoint(coord)
    if coord == "x" then
        return -492
    else
        return 166
    end
end

function characterSpawnPoint(coord)
    if coord == "x" then
        return 180
    else
        return 390
    end
end

function getBackground()
    return "WebPG/assets/images/background3.png"
end

function getTasks()
    local taskList = {
        "- Ramasser la première requête.",          -- 0
        "- S'adresser au serveur.",                 -- 1
        "- Obtenir la page à l'imprimerie",          -- 2
        "- Envoyer les données à l'utilisateur.",   -- 3
        "- Prendre la nouvelle requête.",           -- 4
        "- S'adresser au serveur.",                 -- 5
        "- Accéder à la base de données.",          -- 6
        "- Donner les infos au serveur.",           -- 7
        "- Prendre le fichier à l'imprimerie.",     -- 8
        "- Envoyer les données à l'utilisateur."    -- 9
    }
    return taskList
end

function getGuideSpeech()
    local speech = {
        {
            "Je me meurs...",
            "Il va falloir\ndevenir indépendant.",
            "N'hésite pas à\nconsulter tes missions,",
            "en appuyant sur\nle bouton [Task] en\nhaut de l'écran.",
            "Urrrghh..."
        }
    }
    return speech
end

function getBddSpeech()
    local speech = {
        {
            "Identification :\ndrone joueur.",
            "Quel est la requête ?",
            "...",
            "SELECT id\nFROM users\nWHERE\nemail=reqBody.email;",
            "...",
            "Aucun résultat.",
            "Opération suivante..",
            "INSERT INTO users\n(email,password)\nVALUES (email,hash);",
            "...",
            "Opération finie.",
            "Veuillez communiquer\ndès maintenant le\nrésultat au serveur."
        }
    }
    return speech
end

function getServerSpeech()
    local speech = {
        {
            "Identification :\ndrone joueur.",
            "Présentez moi votre\nrequête.",
            "...",
            "La requête :\naccéder à la page\n/register.",
            "L'utilisateur n'est\npas connecté.",
            "Accès autorisé.",
            "Rédaction...",
            "La page est prête.\nVeuillez la chercher\nà l'imprimerie."
        },
        {
            "Identification :\ndrone joueur.",
            "Présentez moi votre\nrequête.",
            "...",
            "La requête :\nméthode = POST\nroute = /register\nbody = {email,password}",
            "Probe, transmettez\nces données à la base\nde données pour",
            "vérifier que l'email\nn'existe pas déjà et\nqu'il est de bonne forme.",
            "Revenez vers moi\npour me communiquer\nle résultat."
        },
        {
            "Identification :\ndrone joueur.",
            "Reprise de la\nsession précédente.",
            "...",
            "Réponse :\nl'ajout s'est bien\n effectué.",
            "L'utilisateur est\ndonc enregistré.",
            "Attribution de son\nID à cette session.",
            "L'utilisateur est\nmaintenant authentifié.",
            "Recréation de la\npage d'accueil avec\nutilisateur identifié...",
            "...",
            "La page est prête.\nVeuillez la chercher\nà l'imprimerie.",
        }
    }
    return speech
end

function getPrintSpeech()
    local speech = {
        {
            "Votre fichier :\nRegister.vue\nest prêt.",
            "Vous pouvez l'envoyer\nà l'utilisateur pour\nqu'il puisse entrer\nses données.",
        },
        {
            "Votre fichier :\nHome.vue\nest prêt.",
            "Vous pouvez l'envoyer\nà l'utilisateur pour\nqu'il soit redirigé\nvers l'accueil.",
        }
    }
    return speech
end

function guideMovement(guide,map)
    local movement = { 
        { -- move 1
            {
                startTime = 0,
                tween = { guide,
                    { y = guide.y - 64 * 6},
                    {
                        time = 500 * 6,
                        onComplete = function()
                            guide.y = guide.y
                            map[148].value = 5
                        end,
                    }
                }
            },
        },
    }
    return movement
end

function getWinCondition()
    local win = { 123 }
    return win
end