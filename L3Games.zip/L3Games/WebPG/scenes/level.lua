-- -----------------------------------------
-- Import
-- -----------------------------------------
-- Layout
local composer = require("composer")
local relayout = require("relayout")
local userData = require("userData")
local http = require("socket.http")
http.TIMEOUT = 5
local ltn12 = require("ltn12")

-- Sprites
local characterSheetData = require("WebPG.sprites.characterData")
local characterSeqData = require("WebPG.sprites.characterAnimation")

local moveButtonSheetData = require("WebPG.sprites.moveButtonData")
local moveButtonSeqData = require("WebPG.sprites.moveButtonAnimation")

local doorSheetData = require("WebPG.sprites.doorData")
local doorSeqData = require("WebPG.sprites.doorAnimation")

local spawnSheetData = require("WebPG.sprites.spawnData")
local spawnSeqData = require("WebPG.sprites.spawnAnimation")

local eyeBallData = require("WebPG.sprites.eyeBallPurple")

local stationSheetData = require("WebPG.sprites.stationData")
local stationSeqData = require("WebPG.sprites.stationAnimation")


-- Level
local myData = require( "WebPG.scenes.myData" )
local level = require(myData.path)

-- Animation
local animation = require("animation")

-- -----------------------------------------
-- Variables
-- -----------------------------------------
-- --- Layout
local _W, _H, _CX, _CY = relayout._W, relayout._H, relayout._CX, relayout._CY

-- --- Scene
local scene = composer.newScene()

-- --- Groups
local grpMain
local grpWorld
local grpHud

-- --- Variables
-- Font
local font = "WebPG/assets/font/Minecraftia-Regular.ttf"

-- Background
local b1

-- Character Sprite
local characterSheetOptions = characterSheetData.getSpriteSheetData()
local movingCharacterSeq = characterSeqData.getSequenceData()
local characterSpriteSheet = graphics.newImageSheet("WebPG/assets/images/character.png",characterSheetOptions)
local characterMoving

local moveSet = 0
local moveCase

-- Button action
local btnUp
local btnDown
local btnLeft
local btnRight
local btnList = {btnUp,btnDown,btnLeft,btnRight}
local btnInteract
local btnSwitch

-- Button Sprite
local moveButtonSheetOptions = moveButtonSheetData.getSpriteSheetData()
local moveButtonSeq = moveButtonSeqData.getSequenceData()
local moveButtonSpriteSheet = graphics.newImageSheet("WebPG/assets/images/moveButton.png",moveButtonSheetOptions)
local moveButton

-- Door
local doorSheetOptions = doorSheetData.getSpriteSheetData()
local doorSeq = doorSeqData.getSequenceData()
local doorSpriteSheet = graphics.newImageSheet("WebPG/assets/images/blocked.png",doorSheetOptions)

-- Spawn
local spawnSheetOptions = spawnSheetData.getSpriteSheetData()
local spawnSeq = spawnSeqData.getSequenceData()
local spawnSpriteSheet = graphics.newImageSheet("WebPG/assets/images/spawn.png",spawnSheetOptions)
local spawn

-- NPC
local eyeBallPurpleSheetOptions = eyeBallData.getSpriteSheetData()
local eyeBallSeq = eyeBallData.getSequenceData()
local eyeBallSpriteSheet = graphics.newImageSheet("WebPG/assets/images/EyeBall1.png",eyeBallPurpleSheetOptions)

local stationSheetOptions = stationSheetData.getSpriteSheetData()
local stationSeq = stationSeqData.getSequenceData()
local bddSpriteSheet = graphics.newImageSheet("WebPG/assets/images/BDD.png",stationSheetOptions)
local serverSpriteSheet = graphics.newImageSheet("WebPG/assets/images/server.png",stationSheetOptions)

local guide
local guideMovement

local movingNPC = 0

-- Map
local mapTilesDisplay = {}
local entitiesDisplay = {}

-- Dialog
local dialogBox
local underDialogBox
local closeDialogBox

local dialog                -- Title
local underDialog           
local underDialogText       -- Template
local underDialogAnimation
local nextLineButton
local tappyAllow = 0

local dialogNextTap = false
local dialogProgression
local dialogCounter = 1
local guideDialogLine = 1
local serverDialogLine = 1

local isInteracting = 0
local numberNearNPC = 0
local nearestNPC = 0

-- Collision detector
local collision
local mapMove
local rollBackSwitch
local movementSpeed = 4 -- Set movement speed here

-- Animation
local dialogCounter = 1

-- Quests
local btnTask
local tasks
local taskDisplay = {}
local taskProgression = 1
local finishedTask = 0

-- Inventory
local inventory = {}
local keyIsInInventory = 0

-- Win
local semiWin = 0
local dialogWin = {}
local winConditions

-- Miscellaneous
local currentLevel = level.getCurrentLevel()
local back
local sendDataOnce

-- -----------------------------------------
-- LUA Fonctions
-- -----------------------------------------

local function switch(t)
    t.case = function (self,x)
      local f=self[x] or self.default
      if f then
        if type(f)=="function" then
          f(x,self)
        else
          error("case "..tostring(x).." not a function")
        end
      end
    end
    return t
end

local function myLinearEasing( t, tMax, start, delta )
    return delta * t / tMax + start
end

local function tableCompare(table,value)
    for i=1,#table,1 do
        if table[i] == value then
            return 1
        end
    end
    return 0
end

-- -----------------------------------------
-- Fonctions
-- -----------------------------------------

local function greenTask()
    finishedTask = finishedTask+1
    taskDisplay[finishedTask]:setFillColor(0,1,0)
    if taskDisplay[finishedTask+1] ~= nil then
        taskDisplay[finishedTask+1]:setFillColor(1,1,1)
    end
end

local function updateDatabase()
    if sendDataOnce == 0 then
        sendDataOnce = 1
        local reqbody = "level="..myData.level
        local respbody = {}
        local result, respcode, respheaders,respstatus = http.request {
            method = "PUT",
            url = "http://127.0.0.1:5000/updatewebpg",
            source = ltn12.source.string(reqbody),
            headers = {
                ["content-type"] = "application/x-www-form-urlencoded",
                ["content-length"] = tostring(#reqbody)
            },
            body = reqbody,
            sink = ltn12.sink.table(respbody)
        }
    end
end

local function backToFuture()
    composer.removeScene("WebPG.scenes.level")
    composer.gotoScene("WebPG.scenes.menu")
end

local function changeSequence(event)
    if(event.phase == "began") then 
        if event.target == btnUp then
            characterMoving:setSequence('moving-up')
        elseif event.target == btnLeft then
            characterMoving:setSequence('moving-left')
        elseif event.target == btnDown then
            characterMoving:setSequence('moving-down')
        else 
            characterMoving:setSequence('moving-right')
        end
        characterMoving:play()
    end
end

local function buttonOrientation(event)
    if(event.phase == "began") then 
        if event.target == btnUp then
            moveButton:setSequence("press-up")
        elseif event.target == btnDown then
            moveButton:setSequence("press-down")
        elseif event.target == btnLeft then
            moveButton:setSequence("press-left")
        else 
            moveButton:setSequence("press-right")
        end
    elseif event.phase == "ended" then
        moveButton:setSequence("idle")
    end
end

local function moveCharacter(event)
    if event.phase == "began" then
        btnSwitch:case(event.target)
    elseif event.phase == "ended"  then
        moveSet = 0
    end
end

local function checkItem(itemId)
    local canAdd = 1
    for i=1,#inventory,1 do
        if inventory[i] == itemId then
            canAdd = 0 
        end 
    end
    if canAdd == 1 then
        inventory[#inventory+1] = itemId
        removeEntity(itemId)
        if (itemId == 13 or itemId == 11) and currentLevel == 3 then
            greenTask()
        end
    end
end

local function detectCollision(rect1,rect2)
    local collision = 0

    -- Check if floor
    if rect2.value ~= 0 then
        
        -- Check if near a wall/entities
        if rect2.display.x-rect1.x < 128 and
        rect2.display.x-rect1.x > -128 and
        rect2.display.y-rect1.y < 128 and
        rect2.display.y-rect1.y > -128 then

            -- Direct Collision
            if rect1.x < rect2.display.x + rect2.display.width and
            rect1.x + rect1.width > rect2.display.x  and
            rect1.y < rect2.display.y + rect2.display.height and
            rect1.height + rect1.y > rect2.display.y then
                if rect2.value < 10 then
                    collision = 1
                elseif rect2.value < 99 then
                    checkItem(rect2.value)
                end
            end

            -- Near entity
            nearNPC()
        end
    end
    return collision
end

local function initMoveCase()
    moveCase = switch {
        -- UP
        [1] = function ()
            --Check if character is in middle of screen
            if (characterMoving.y >= display.contentCenterY) and (characterMoving.y - movementSpeed > 32) then
                characterMoving.y = characterMoving.y - movementSpeed
            elseif b1.y + movementSpeed < 0  then -- Moving normally
                mapMove = 1
                b1.y = b1.y + movementSpeed
                for i = #mapTilesDisplay, 1, -1 do
                    mapTilesDisplay[i].display.y = mapTilesDisplay[i].display.y + movementSpeed
                end
                for i = #entitiesDisplay, 1, -1 do
                    entitiesDisplay[i].display.y = entitiesDisplay[i].display.y + movementSpeed
                end
            elseif b1.y + movementSpeed >= 0 and (characterMoving.y - movementSpeed > 32) then -- Reached border
                characterMoving.y = characterMoving.y - movementSpeed
            end
        end,
        -- LEFT
        [2] = function () 
            if (characterMoving.x >= display.contentCenterX) and (characterMoving.x - movementSpeed > 32) then
                characterMoving.x = characterMoving.x - movementSpeed
            elseif b1.x + movementSpeed < 0  then
                mapMove = 1
                b1.x = b1.x + movementSpeed
                for i = #mapTilesDisplay, 1, -1 do
                    mapTilesDisplay[i].display.x = mapTilesDisplay[i].display.x + movementSpeed
                end
                for i = #entitiesDisplay, 1, -1 do
                    entitiesDisplay[i].display.x = entitiesDisplay[i].display.x + movementSpeed
                end
            elseif b1.x + movementSpeed >= 0 and characterMoving.x - movementSpeed > 32 then
                characterMoving.x = characterMoving.x - movementSpeed
            end
        end,
        -- DOWN
        [3] = function ()  
            if (characterMoving.y <= display.contentCenterY) and (characterMoving.y + movementSpeed < display.contentHeight-32) then
                characterMoving.y = characterMoving.y + movementSpeed   
            elseif mapTilesDisplay[#mapTilesDisplay].display.y - movementSpeed > (display.contentHeight)-32 then
                mapMove = 1
                b1.y = b1.y - movementSpeed
                for i = #mapTilesDisplay, 1, -1 do
                    mapTilesDisplay[i].display.y = mapTilesDisplay[i].display.y - movementSpeed
                end
                for i = #entitiesDisplay, 1, -1 do
                    entitiesDisplay[i].display.y= entitiesDisplay[i].display.y - movementSpeed
                end
            elseif mapTilesDisplay[#mapTilesDisplay].display.y - movementSpeed <= (display.contentHeight)-32 and (characterMoving.y + movementSpeed < display.contentHeight-32) then -- Reached border
                characterMoving.y = characterMoving.y + movementSpeed
            end
        end,
        -- RIGHT
        [4] = function ()  
            if (characterMoving.x <= display.contentCenterX) and (characterMoving.x + movementSpeed < 330) then
                characterMoving.x = characterMoving.x + movementSpeed
            elseif mapTilesDisplay[#mapTilesDisplay].display.x - movementSpeed > (display.contentWidth)-32 then -- Moving normally
                mapMove = 1
                b1.x = b1.x - movementSpeed
                for i = #mapTilesDisplay, 1, -1 do
                    mapTilesDisplay[i].display.x = mapTilesDisplay[i].display.x - movementSpeed
                end
                for i = #entitiesDisplay, 1, -1 do
                    entitiesDisplay[i].display.x = entitiesDisplay[i].display.x - movementSpeed
                end
            elseif mapTilesDisplay[#mapTilesDisplay].display.x - movementSpeed <= (display.contentWidth)-32 and characterMoving.x + movementSpeed < 330 then -- Reached border
                characterMoving.x = characterMoving.x + movementSpeed
            end
        end,
        default = function () end,
    }
end

local function initRollBack()
    rollBackSwitch = switch {
        [1] = function ()
            if mapMove == 0 then
                characterMoving.y = characterMoving.y + movementSpeed
            else
                b1.y = b1.y - movementSpeed
                for i = #mapTilesDisplay, 1, -1 do
                    mapTilesDisplay[i].display.y = mapTilesDisplay[i].display.y - movementSpeed
                end
                for i = #entitiesDisplay, 1, -1 do
                    entitiesDisplay[i].display.y = entitiesDisplay[i].display.y - movementSpeed
                end
            end
        end,
        [2] = function ()
            if mapMove == 0 then
                characterMoving.x = characterMoving.x + movementSpeed
            else
                b1.x = b1.x - movementSpeed
                for i = #mapTilesDisplay, 1, -1 do
                    mapTilesDisplay[i].display.x = mapTilesDisplay[i].display.x - movementSpeed
                end
                for i = #entitiesDisplay, 1, -1 do
                    entitiesDisplay[i].display.x = entitiesDisplay[i].display.x - movementSpeed
                end
            end
        end,  
        [3] = function ()
            if mapMove == 0 then
                characterMoving.y = characterMoving.y - movementSpeed
            else
                b1.y = b1.y + movementSpeed
                for i = #mapTilesDisplay, 1, -1 do
                    mapTilesDisplay[i].display.y = mapTilesDisplay[i].display.y + movementSpeed
                end
                for i = #entitiesDisplay, 1, -1 do
                    entitiesDisplay[i].display.y = entitiesDisplay[i].display.y + movementSpeed
                end
            end
        end,
        [4] = function ()
            if mapMove == 0 then
                characterMoving.x = characterMoving.x - movementSpeed
            else
                b1.x = b1.x + movementSpeed
                for i = #mapTilesDisplay, 1, -1 do
                    mapTilesDisplay[i].display.x = mapTilesDisplay[i].display.x + movementSpeed
                end
                for i = #entitiesDisplay, 1, -1 do
                    entitiesDisplay[i].display.x = entitiesDisplay[i].display.x + movementSpeed
                end
            end
        end,
    }
end

function nearNPC()
    local test = 0
    for i = #mapTilesDisplay,1,-1 do
        -- NPC close enough
        if mapTilesDisplay[i].value > 1 then
            if mapTilesDisplay[i].display.x-characterMoving.x < 90 and
            mapTilesDisplay[i].display.x-characterMoving.x > -90 and
            mapTilesDisplay[i].display.y-characterMoving.y < 90 and
            mapTilesDisplay[i].display.y-characterMoving.y > -90 and
            mapTilesDisplay[i].value < 10 then
                test = test + 1
                nearestNPC = mapTilesDisplay[i].value
            end
        end
    end
    numberNearNPC = test
end

local function checkNearNPC()
    -- NPC Interact
    if numberNearNPC > 0 then
        btnInteract.alpha = 1
    else
        btnInteract.alpha = 0
    end
end

local function checkDoor()
    if keyIsInInventory == 1 and nearestNPC == 2 then
        keyIsInInventory = 0
        guideDialogLine = guideDialogLine + 1
        if currentLevel == 1 then
            movingNPC = 1
            moveGuide(1)
        end
        removeEntity(2)
    elseif keyIsInInventory == 1 and nearestNPC == 4 then
        keyIsInInventory = 0
        removeEntity(4)
    elseif guideDialogLine == 1 and inventory[#inventory] == 12 and nearestNPC == 9 then
        guideDialogLine = guideDialogLine + 1
        movingNPC = 1
        moveGuide(1)
    end
end

local function closeInteractNPC(event)
    if isInteracting == 1 then
        underDialogBox:removeEventListener("touch",closeInteractNPC)
        closeDialogBox:removeEventListener("touch",closeInteractNPC)
        closeDialogBox.alpha = 0
        nextLineButton.alpha = 0
        if currentLevel == 3 and nearestNPC == 5 then
            removeEntity(5)
        end
        checkDoor()
        dialogBoxScaleOut()
        closeUnderDialog()
        translateRightTitle()
        checkWin()
    end
end

function setUnderDialog()
    if nearestNPC == 2 then
        dialog.text = "Porte BDD"
        npcLines = {"Vous n'avez pas accès\nsans autorisation !"}
        for i = 1,#inventory,1 do
            if inventory[i] == 10 then
                npcLines[#npcLines+1] = "Mais je vois que\nvous avez l'autorisation\npour passer."
                keyIsInInventory = 1
            end
        end
    elseif nearestNPC == 3 then
        dialog.text = "Porte API"
        npcLines = {"Vous n'avez pas accès\nsans autorisation !"}
    elseif nearestNPC == 4 then
        dialog.text = "Porte S"
        npcLines = {"Vous n'avez pas accès\nsans autorisation !"}
        for i = 1,#inventory,1 do
            if inventory[i] == 13 then
                npcLines[#npcLines+1] = "Mais je vois que\nvous avez une carte\npour accéder au\nserveur."
                keyIsInInventory = 1
            end
        end
    elseif nearestNPC == 5 then
        dialog.text = "Guide"
        npcLines = level.getGuideSpeech()[guideDialogLine]
        if currentLevel == 2 and tableCompare(inventory,12) == 1 then
            dialogWin = inventory
            inventory[#inventory+1] = 13
        end
    elseif nearestNPC == 7 then
        dialog.text = "BDD"
        npcLines = level.getBddSpeech()[1]
        if currentLevel == 1 then
            addWin(nearestNPC)
        elseif currentLevel == 3 and finishedTask == 6 then
            greenTask()
            serverDialogLine = serverDialogLine + 1
        end
    elseif nearestNPC == 8 then
        dialog.text = "Server"
        if currentLevel == 1 then
            addWin(nearestNPC)
        elseif currentLevel == 2 then
            if tableCompare(inventory,11) == 1 and tableCompare(inventory,12) == 0 then
                inventory[#inventory+1] = 12
                serverDialogLine = serverDialogLine + 1
            end
        elseif currentLevel == 3 then
            if finishedTask == 1 or finishedTask == 7 then
                greenTask()
            elseif finishedTask == 5 then
                greenTask()
                serverDialogLine = serverDialogLine + 1
                inventory[#inventory+1] = 10
            end
        end
        npcLines = level.getServerSpeech()[serverDialogLine]
    elseif nearestNPC == 9 then
        dialog.text = "Imprimante"
        if currentLevel == 2 then
            for i = 1,#inventory,1 do
                if inventory[i] == 12 then
                    keyIsInInventory = 12
                end
            end
            if keyIsInInventory == 12 then
                npcLines = level.getPrintSpeech()[1]
            else
                npcLines = {"Aucun fichier en cours."}
            end
        elseif currentLevel == 3 then
            if finishedTask == 2 then
                greenTask()
                semiWin = 1
                spawn:setSequence("green")
                spawn:play()
                npcLines = level.getPrintSpeech()[1]
            elseif finishedTask == 8 then
                greenTask()
                dialogWin = { 123 }
                npcLines = level.getPrintSpeech()[2]
            else
                npcLines = {"Aucun fichier en cours."}
            end
        else
            npcLines = {"Aucun fichier en cours."}
        end
    end

    underDialogWrite(1)
end

local function interactNPC(event)
    if event.phase == "began" then
        if isInteracting == 0 then
            isInteracting = 1
            dialogNextTap = false
            closeDialogBox:addEventListener("touch",closeInteractNPC)
            dialogBox.alpha = 0.8
            underDialogBox.alpha = 1
            btnState("disabled")
            moveSet = 0
            translateLeftTitle()
            dialogBoxScaleIn()
            setUnderDialog()
        end
    end
end

local function closeInteractComplete()
    dialog.text = ""
    underDialog.text = ""
    dialogBox.alpha = 0
    closeDialogBox.alpha = 0
    underDialogBox.alpha = 0
    tappyAllow = 0
    nextLineButton.alpha = 0
    dialogNextTap = false
    if movingNPC == 0 then
        btnState("enabled")
    end
    underDialogBox.y = display.contentHeight/1.5
    underDialogAnimation = ""
    underDialogText = ""
    dialogCounter = 1
    isInteracting = 0
    underDialogBox:removeEventListener("touch",nextLine)
end

local function createDoor(entityNumber,k,pos)
    local entityDisplay = display.newSprite(grpWorld,doorSpriteSheet,doorSeq)
    entityDisplay:scale(2,2)
    if entityNumber == 2 then
        entityDisplay:rotate(270)
        entityDisplay.x = (b1.x + 32) + 64 * (k-1)
        entityDisplay.y = (b1.y + 128) + 64* (pos-1)
    elseif entityNumber == 3 then
        entityDisplay.x = (b1.x + 128) + 64 * (k-1)
        entityDisplay.y = (b1.y + 32) + 64* (pos-1)
    elseif entityNumber == 4 then
        entityDisplay:rotate(90)
        entityDisplay.x = (b1.x + 32) + 64 * (k-1)
        entityDisplay.y = (b1.y + 128) + 64* (pos-1)
    end
    entityDisplay:play()
    entitiesDisplay[#entitiesDisplay+1] = {display = entityDisplay, value = entityNumber}
end

local function createEntity(entityNumber,k,pos)
    local entityDisplay
    if entityNumber == 5 then       -- Guide
        entityDisplay = display.newSprite(grpWorld,eyeBallSpriteSheet,eyeBallSeq)
        entityDisplay.x = (b1.x + 32) + 64 * (k-1)
        entityDisplay.y = (b1.y + 32) + 64 * (pos-1)
        entityDisplay:play()
        guide = entityDisplay
    elseif entityNumber == 7 then   -- BDD
        entityDisplay = display.newSprite(grpWorld,bddSpriteSheet,stationSeq)
        entityDisplay.x = (b1.x + 96) + 64 * (k-1)
        entityDisplay.y = (b1.y + 64) + 64 * (pos-1)
        entityDisplay:play()
        if currentLevel == 3 then
            entityDisplay:rotate(90)
            entityDisplay.x = (b1.x + 32) + 64 * (k-1)
            entityDisplay.y = (b1.y + 96) + 64 * (pos-1)
        end
    elseif entityNumber == 8 then   -- Server
        entityDisplay = display.newSprite(grpWorld,serverSpriteSheet,stationSeq)
        entityDisplay.x = (b1.x + 96) + 64 * (k-1)
        entityDisplay.y = (b1.y + 64) + 64 * (pos-1)
        entityDisplay:play()
    elseif entityNumber == 9 then   -- Print
        entityDisplay = display.newImageRect(grpWorld,"WebPG/assets/images/print.png",192,64)
        if currentLevel == 2 then
            entityDisplay:rotate(90)
        elseif currentLevel == 3 then
            entityDisplay:rotate(270)
        end
        entityDisplay.x = (b1.x + 32) + 64 * (k-1)
        entityDisplay.y = (b1.y + 96) + 64 * (pos-1)
    end
    entitiesDisplay[#entitiesDisplay+1] = { display = entityDisplay, value = entityNumber }
end

local function createItem(entityNumber,k,pos)
    local entityDisplay = display.newImageRect(grpWorld,"WebPG/assets/images/card.png",64,64)
    entityDisplay.x = (b1.x + 32) + 64 * (k-1)
    entityDisplay.y = (b1.y + 32) + 64 * (pos-1)
    entitiesDisplay[#entitiesDisplay+1] = {display = entityDisplay, value = entityNumber}
end

function removeEntity(value)
    for i=1,#mapTilesDisplay,1 do
        if mapTilesDisplay[i].value == value then
            mapTilesDisplay[i].value = 0
        end
    end
    for i=1,#entitiesDisplay,1 do
        if entitiesDisplay[i].value == value then
            entitiesDisplay[i].display.alpha = 0
        end
    end
end

local function loadMap()
    local map = level.getMap()
    local entityNumberList = {}
    for k,v in pairs(map) do
        for pos,tile in pairs(v) do 
            -- Tiles setup
            local tileDisplay = display.newRect(grpWorld,(b1.x + 32) + 64 * (k-1), (b1.y + 32) + 64* (pos-1), 64, 64 )-- initiates the square
            tileDisplay.alpha = 0.01
            local function showCase()
                tileDisplay.alpha = 0.8
                if tile ~= 0 then
                    tileDisplay:setFillColor(0,0,255)
                end
                tileDisplay:setStrokeColor(140, 140, 140)
                tileDisplay.strokeWidth = 2
            end
            --showCase()
            mapTilesDisplay[#mapTilesDisplay+1] = {
                display = tileDisplay,
                value = tile
            }

            -- Entity setup
            if tile > 1 then
                local approval = 1
                for i = #entityNumberList,1,-1 do
                    if tile == entityNumberList[i] then
                        approval = 0
                    end
                end
                if approval == 1 then
                    entityNumberList[#entityNumberList+1] = tile
                    if tile < 5 then
                        createDoor(tile,k,pos)
                    elseif tile < 10 then
                        createEntity(tile,k,pos)
                    else
                        createItem(tile,k,pos)
                    end
                end
            end
        end
    end
end

local function closeTasks()
    dialogBox.alpha = 0
    for i=1,#taskDisplay,1 do
        taskDisplay[i].alpha = 0
    end
    btnState("enabled")
    isInteracting = 0
    closeDialogBox.alpha = 0
    closeDialogBox:removeEventListener("touch",closeTasks)
end

local function showTasks()
    if isInteracting == 0 then
        for i=1,#taskDisplay,1 do
            taskDisplay[i].alpha = 1
        end
        btnState("disabled")
        dialogBox.alpha = 0.8
        closeDialogBox.alpha = 1
        isInteracting = 1
        moveSet = 0
        closeDialogBox:addEventListener("touch",closeTasks)
    end
end

function btnState(state)
    if state == "enabled" then
        for i = #btnList,1,-1 do
            btnList[i]:addEventListener("touch",changeSequence)
            btnList[i]:addEventListener("touch",moveCharacter)
            btnList[i]:addEventListener("touch",buttonOrientation)
        end
        btnTask:addEventListener("touch",showTasks)
        back:addEventListener("touch",backToFuture)
        btnInteract:addEventListener("touch",interactNPC)
    else
        for i = #btnList,1,-1 do
            btnList[i]:removeEventListener("touch",changeSequence)
            btnList[i]:removeEventListener("touch",moveCharacter)
            btnList[i]:removeEventListener("touch",buttonOrientation)
        end
        btnTask:removeEventListener("touch",showTasks)
        back:removeEventListener("touch",backToFuture)
        btnInteract:removeEventListener("touch",interactNPC)
    end
end

function nextLine(event)
    if event.phase == "began" then
        dialogNextTap = true
        underDialogWrite(dialogProgression)
    end
end

function addOneLetter(index)
    underDialogText = npcLines[index]
    if underDialogText ~= underDialogAnimation then -- Write till whole line is written
        underDialogAnimation = underDialogAnimation .. string.sub(underDialogText,dialogCounter,dialogCounter)
        underDialog.text = underDialogAnimation
        dialogCounter = dialogCounter + 1
        dialogProgression = index
        underDialogWrite(index)
    elseif (index+1 <= #npcLines) and dialogNextTap == false then
        tappyAllow = 1
        tappyTapTap()
        dialogProgression = index
        underDialogBox:addEventListener("touch",nextLine)
    elseif (index+1 <= #npcLines) and dialogNextTap == true then
        underDialogBox:removeEventListener("touch",nextLine)
        tappyAllow = 0
        nextLineButton.alpha = 0
        underDialog.text = ""
        underDialogAnimation = ""
        dialogNextTap = false
        dialogCounter = 1
        if npcLines[index+1] ~= nil then
            underDialogWrite(index+1)
        end
    else
        underDialogBox:addEventListener("touch",closeInteractNPC)
    end
end

function returnedToSpawn()
    if spawn.x - 32 <= characterMoving.x and
    spawn.y - 32 <= characterMoving.y and
    spawn.x + 32 >= characterMoving.x and
    spawn.y + 32 >= characterMoving.y then
        if semiWin == 0 then
            semiWin = 9
            currentLevel = currentLevel + 1
            if myData.level < currentLevel then
                myData.level = currentLevel
                userData.webpg = userData.webpg + 1
            end
            
            if userData.id ~= nil and sendDataOnce == 0 then
                updateDatabase()
            end
            getOutOfLevel()
        else
            if currentLevel == 3 then
                semiWin = 0
                spawn:setSequence("red")
                spawn:play()
                createItem(11,11,9)
                mapTilesDisplay[159].value = 11
                greenTask()
            end
        end
    end
end

local function update()
    -- NPC Interact
    checkNearNPC()
    -- Movement
    collision = 0
    mapMove = 0
    moveCase:case(moveSet)
    for i = #mapTilesDisplay, 1, -1 do
        if detectCollision(characterMoving,mapTilesDisplay[i]) == 1 then
            rollBackSwitch:case(moveSet)
            break
        end
    end
    if(winConditions[#winConditions] == -1 or semiWin == 1) then
        returnedToSpawn()
    end
end



-- -----------------------------------------
-- Animation
-- -----------------------------------------
function getOutOfLevel()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 0,
                tween = { characterMoving,
                    { yScale = 2,xScale = 2,y = -100},
                    {
                        time = 1000,
                        onComplete = function()
                            composer.gotoScene("WebPG.scenes.menu")
                        end
                    }
                }
            }
        },
    })
    newTimeline:resume()
end

function moveGuide(sequence)
    for i=1,#mapTilesDisplay,1 do
        if mapTilesDisplay[i].value == 5 then
            mapTilesDisplay[i].value = 0
            break
        end
    end
    moveSet = 0
    btnState("disabled")
    guideMovement = level.guideMovement(guide,mapTilesDisplay)
    local newTimeline = animation.newTimeline( {
        tweens = guideMovement[sequence],
        onComplete = function()
            btnState("enabled")
            movingNPC = 0
        end
    })
    newTimeline:resume()
end

function tappyTapTap()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 500,
                tween = { nextLineButton,
                    { alpha = 1 },
                    {
                        time = 1,
                    }
                }
            },
            {
                startTime = 1000,
                tween = { nextLineButton,
                    { alpha = 0 },
                    {
                        time = 1,
                        onComplete = function()
                            if tappyAllow == 1 then
                                tappyTapTap()
                            end
                        end
                    }
                }
            }
        },
    })
    newTimeline:resume()
end

function launchedAnimation()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 0,
                tween = { grpWorld,
                    { alpha = 1 },
                    {
                        time = 1000,
                        onComplete = function()
                            grpHud.alpha = 1
                        end
                    }
                }
            }
        },
    })
    newTimeline:resume()
end

-- Dialog box scale in
function dialogBoxScaleIn()
    local newTimeline = animation.newTimeline( {
        tweens = {
            { 
                startTime = 0, 
                tween = { underDialogBox, 
                    { xScale = 0.01, yScale = 0.01 }, 
                    { 
                        time = 0.01,
                        easing = myLinearEasing
                    } 
                } 
            },
            {
                startTime = 0,
                tween = { underDialogBox, 
                    { xScale = 1, yScale = 1 }, 
                    { 
                        time = 500,
                        easing = myLinearEasing
                    }
                } 
            }
        },
    })
    newTimeline:resume()
end

function dialogBoxScaleOut()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 0,
                tween = { underDialogBox,
                    { y = underDialogBox.y+100 }, 
                    { 
                        time = 200,
                    }
                } 
            },
            {
                startTime = 200,
                tween = { underDialogBox,
                    { y = -display.contentHeight },
                    {
                        time = 600,
                        onComplete = function()
                            closeInteractComplete()
                        end
                    }
                }
            }
        },
    })
    newTimeline:resume()
end

function closeUnderDialog()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 0,
                tween = { underDialog,
                    { xScale = 1.2, yScale = 1.2 }, 
                    { 
                        time = 200,
                    }
                } 
            },
            {
                startTime = 200,
                tween = { underDialog,
                    { xScale = 0.01, yScale = 0.01 },
                    {
                        time = 600,
                        onComplete = function()
                            underDialog.xScale = 1
                            underDialog.yScale = 1
                        end,
                    }
                }
            }
        },
    })
    newTimeline:resume()
end

function translateRightTitle()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 0,
                tween = { dialog,
                    { x = dialog.x + 50 }, 
                    { 
                        time = 200,
                    }
                } 
            },
            {
                startTime = 200,
                tween = { dialog,
                    { x = -display.contentWidth },
                    {
                        time = 600,
                        onComplete = function()
                            dialog.x = display.contentWidth
                        end,
                    }

                }
            }
        },
    })
    newTimeline:resume()
end

function translateLeftTitle()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 0,
                tween = { dialog,
                    { x = (display.contentWidth/2) - 20 },
                    { 
                        time = 300,
                    }
                }
            },
            {
                startTime = 300,
                tween = { dialog,
                    { x = display.contentWidth/2 },
                    {
                        time = 300,
                    }
                }
            }
        },
    })
    newTimeline:resume()
end

function underDialogWrite(index)
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 0,
                tween = { underDialog,
                    { alpha = 0.99 },
                    {
                        time = 30,
                        onComplete = function()
                            alpha = 1
                            if isInteracting == 1 then
                                addOneLetter(index)
                            end
                        end,
                    }
                }
            }
        },
    })
    newTimeline:resume()
end

function addWin(npc)
    local canAdd = 1
    for i=1,#dialogWin,1 do
        if dialogWin[i] == npc then
            canAdd = 0
        end
    end
    if canAdd == 1 then
        dialogWin[#dialogWin+1] = npc
    end
end

function checkWin()
    local won = 0
    for i = 1,#dialogWin,1 do
        for j = 1,#winConditions,1 do
            if dialogWin[i] == winConditions[j] then
                won = won+1
            end
        end
    end

    if won == #winConditions then
        spawn:setSequence("green")
        spawn:play()
        if currentLevel == 1 then
            movingNPC = 1
            moveGuide(2)
            guideDialogLine = guideDialogLine+1
        end
        greenTask()
        winConditions[#winConditions+1] = -1
    end
end

-- -----------------------------------------
-- Scene event functions
-- -----------------------------------------

-- create()
function scene:create(event)
    print("scene:create - level1")

    -- Create main group and insert
    grpMain = display.newGroup()
    self.view:insert(grpMain)

    grpWorld = display.newGroup()
    grpMain:insert(grpWorld)
    grpWorld.alpha = 0
    grpHud = display.newGroup()
    grpMain:insert(grpHud)
    grpHud.alpha = 0
    -- Insert objects to grpMain here
    -- -------------------------------
    -- --- Sprites
    -- -------------------------------
    -- Background
    b1 = display.newImageRect(grpWorld,level.getBackground(),level.getSize("width"),level.getSize("height"))
    b1.anchorX = 0
    b1.anchorY = 0
    b1.x = level.mapSpawnPoint("x")
    b1.y = level.mapSpawnPoint("y")

    loadMap()
    -- Spawn (inactive)
    spawn = display.newSprite(grpWorld,spawnSpriteSheet,spawnSeq)
    spawn.x = level.characterSpawnPoint("x")
    spawn.y = level.characterSpawnPoint("y")
    spawn:setSequence("red")
    spawn:play()
    entitiesDisplay[#entitiesDisplay+1] = {display = spawn, value = 99}

    -- Character
    characterMoving = display.newSprite(grpWorld,characterSpriteSheet,movingCharacterSeq)
    characterMoving:play()
    characterMoving.x = level.characterSpawnPoint("x")
    characterMoving.y = level.characterSpawnPoint("y")

    -- 

    -- -------------------------------
    -- --- Buttons
    -- -------------------------------
    -- Leave
    back = display.newImageRect(grpHud,"WebPG/assets/images/exit.png",64,64)
    back.x = 45
    back.y = 150

    -- Move buttons
    moveButton = display.newSprite(grpHud,moveButtonSpriteSheet,moveButtonSeq)
    btnInteract = display.newImageRect(grpHud,"WebPG/assets/images/interactSpeak.png",50,50)
    moveButton:play()
    moveButton.x = display.contentWidth/4
    moveButton.y = display.contentHeight - display.contentHeight/4
    btnInteract.x = display.contentWidth - display.contentWidth/4
    btnInteract.y = display.contentHeight - display.contentHeight/4
    btnInteract.alpha = 0
    btnInteract:scale(2,2)

    -- Press detector
    btnUp = display.newRect(moveButton.x,moveButton.y-40,40,60)
    btnDown = display.newRect(moveButton.x,moveButton.y+40,40,60)
    btnLeft = display.newRect(moveButton.x-40,moveButton.y,60,40)
    btnRight = display.newRect(moveButton.x+40,moveButton.y,60,40)
    btnList = { btnUp,btnDown,btnLeft,btnRight }
    for i = #btnList,1,-1 do
        btnList[i].alpha = 0.01 -- Not 0 because they need to exist
    end

    btnTask = display.newImageRect(grpHud,"WebPG/assets/images/tasks.png",75,75)

    -- Dialog
    dialogBox = display.newRect(grpHud,0,0,display.contentWidth*2,display.contentHeight*2)
    underDialogBox = display.newImageRect(grpHud,"WebPG/assets/images/dialogBox.png",display.contentWidth/1.1,display.contentWidth/1.1)
    dialog = display.newText(grpHud,"",display.contentWidth,display.contentHeight * 0.25,font,48)
    underDialog = display.newText(grpHud,"",display.contentWidth/2,display.contentHeight/1.5,font,16)
    nextLineButton = display.newText(grpHud,">",display.contentWidth/2,underDialog.y*1.2,font,30)
    underDialogAnimation = ""
    
    closeDialogBox = display.newImageRect(grpHud,"WebPG/assets/images/close.png",50,50)
    closeDialogBox.x = display.contentWidth-50
    closeDialogBox.y = 50
    
    underDialogBox.x = display.contentWidth/2
    underDialogBox.y = display.contentHeight/1.5
    dialogBox:setFillColor(0,0,0)
    dialogBox.alpha = 0
    closeDialogBox.alpha = 0
    underDialogBox.alpha = 0
    nextLineButton.alpha = 0

    -- Tasks
    btnTask.x = 50
    btnTask.y = 50
    tasks = level.getTasks()
    for i=1,#tasks,1 do
        local displayTask = display.newText(grpHud,tasks[i],_CX,(_CY/4)+i*30,font,15)
        taskDisplay[#taskDisplay+1] = displayTask
        displayTask.alpha = 0
        if i > 1 then
            displayTask:setFillColor(0.3)
        end
    end
    -- -------------------------------
    -- --- Switch
    -- -------------------------------
    -- Move buttons
    btnSwitch = switch {
        [btnUp] = function () moveSet = 1 end,
        [btnLeft] = function () moveSet = 2 end,
        [btnDown] = function () moveSet = 3 end,
        [btnRight] = function () moveSet = 4 end,
    }
    initMoveCase()
    initRollBack()
    launchedAnimation()
    winConditions = level.getWinCondition()
    --winConditions = { -1 }
    -- ---
    btnState("enabled")
    --
    sendDataOnce = 0    
    Runtime:addEventListener("enterFrame",update)
end

-- show()
function scene:show(event)
    if(event.phase == "will") then
    elseif(event.phase == "did") then
    end
end

-- hide()
function scene:hide(event)
    if(event.phase == "will") then
    elseif(event.phase == "did") then
    end
end

-- destroy()
function scene:destroy(event)
    print("DESTROYED")
    grpHud:removeSelf()
    grpWorld:removeSelf()
    Runtime:removeEventListener("enterFrame",update)
    btnInteract:removeEventListener("touch",interactNPC)
    closeDialogBox:removeEventListener("touch",closeInteractNPC)
    Runtime:removeEventListener("enterFrame",update)
    for i = #btnList,1,-1 do
        btnList[i]:removeEventListener("touch",changeSequence)
        btnList[i]:removeEventListener("touch",moveCharacter)
        btnList[i]:removeEventListener("touch",buttonOrientation)
    end
    for i = #btnList,1,-1 do
        btnList[i]:removeSelf()
    end
end
-- -----------------------------------------
-- Scene event functions listeners
-- -----------------------------------------
scene:addEventListener("create",scene)
scene:addEventListener("show",scene)
scene:addEventListener("hide",scene)
scene:addEventListener("destroy",scene)
-- -----------------------------------------

return scene