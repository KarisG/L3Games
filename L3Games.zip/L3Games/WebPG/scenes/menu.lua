--------------------------------------------
-- Import
--------------------------------------------

local composer = require("composer")
local relayout = require("relayout")
local myData = require("WebPG.scenes.myData")
local userData = require("userData")
local animation = require("animation")

-- -----------------------------------------
-- Variables
-- -----------------------------------------

-- layout
local _W, _H, _CX, _CY = relayout._W, relayout._H, relayout._CX, relayout._CY

-- Scene
local scene = composer.newScene()

-- Groups
local grpMain

-- Buttons
local btnLv1
local btnLv2
local btnStart
local btnGroup

local hasTapped = 0

-- Background
local b1

-- Logo
local logo

-- Progression

if userData.id ~= nil then
    myData.level = userData.webpg
elseif(myData.level == nil)then
    myData.level = 1
end
local currentLevel = myData.level
local levelSuggestion
local scrollingMessage

-- Visual
local selectedLevel
local select

-- -----------------------------------------
-- Functions
-- -----------------------------------------

function goTo(event)
    if event.phase == "began" then
        levelSuggestion.alpha = 0
        scrollingMessage.alpha = 0
        if event.target == btnLv1 then
            selectedLevel.text = "Tutoriel"
            myData.path = "WebPG.level.level1"
        elseif event.target == btnLv2 then
            selectedLevel.text = "Erreur"
            myData.path = "WebPG.level.level2"
        elseif event.target == btnLv3 then
            selectedLevel.text = "Authentification"
            myData.path = "WebPG.level.level3"
        elseif event.target == btnLv5 then
            selectedLevel.text = "Bye bye"
            composer.removeScene("WebPG.scenes.menu",true)
            composer.removeScene("WebPG.scenes.level",true)
            composer.gotoScene("scenes.menu")
        end
        removeButtonsEventListener()
        slideOutLevel()
    end
end

function buttonsEventListener()
    if myData.level > 0 then
        btnLv1:addEventListener("touch",goTo)
    end

    if myData.level > 1 then
        btnLv2:addEventListener("touch",goTo)
    end

    if myData.level > 2 then
        btnLv3:addEventListener("touch",goTo)
    end
    
    if myData.level > 3 then

    end

    if myData.level > 4 then

    else

    end

    btnLv5:addEventListener("touch",goTo)
end

function removeButtonsEventListener()
    if myData.level > 0 then
        btnLv1:removeEventListener("touch",goTo)
    end

    if myData.level > 1 then
        btnLv2:removeEventListener("touch",goTo)
    end

    if myData.level > 2 then
        btnLv3:removeEventListener("touch",goTo)
    end
    
    if myData.level > 3 then

    end

    if myData.level > 4 then

    else

    end

    btnLv5:removeEventListener("touch",goTo)
end

-- -----------------------------------------
-- Animation
-- -----------------------------------------

function slideDownLogo()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 0,
                tween = { logo,
                    { y = (display.contentHeight/3)+20 }, 
                    { 
                        time = 500,
                    }
                } 
            },
            {
                startTime = 600,
                tween = { logo,
                    { y = display.contentHeight/3 },
                    {
                        time = 200,
                        onComplete = function()
                            Runtime:addEventListener("tap",slideUpLogo)
                            fadeInFadeOutTap()
                        end,
                    }

                }
            }
        },
    })
    newTimeline:resume()
end

function slideUpLogo()
    Runtime:removeEventListener("tap",slideUpLogo)
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 0,
                tween = { logo,
                    { y = (display.contentHeight/3)+20 }, 
                    { 
                        time = 200,
                    }
                } 
            },
            {
                startTime = 200,
                tween = { logo,
                    { y = -310 },
                    {
                        time = 600,
                        onComplete = function()
                            hasTapped = 1
                            btnStart:removeSelf()
                            slideInLevel()
                        end,
                    }
                }
            }
        },
    })
    newTimeline:resume()
end

function slideInLevel()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 0,
                tween = { select,
                    { y = _CY/4,alpha = 1 },
                    {
                        time = 500
                    }
                }
            },
            {
                startTime = 0,
                tween = { btnLv1,
                    { y = _CY*2/4,alpha = 1 }, 
                    { 
                        time = 500,
                    }
                } 
            },
            {
                startTime = 0,
                tween = { btnLv2,
                    { y = _CY*3/4,alpha = 1 }, 
                    { 
                        time = 600,
                    }
                } 
            },
            {
                startTime = 0,
                tween = { btnLv3,
                    {  y = _CY,alpha = 1 }, 
                    { 
                        time = 700,
                    }
                } 
            },
            {
                startTime = 0,
                tween = { btnLv4,
                    {  y = _CY*5/4,alpha = 1 }, 
                    { 
                        time = 800,
                    }
                } 
            },
            {
                startTime = 0,
                tween = { btnLv5,
                    {  y = _CY*6/4,alpha = 1 }, 
                    { 
                        time = 900,
                        onComplete = function()
                            scrollingMessage.alpha = 0.5
                            levelSuggestion.alpha = 1
                            slidingMessage()
                            buttonsEventListener()
                        end,
                    }
                } 
            },
        },
    })
    newTimeline:resume()
end

function wholeFade()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 0,
                tween = { grpMain,
                    { alpha = 0.01 },
                    {
                        time = 500,
                        onComplete = function()
                            selectedLevel.alpha = 1
                        end
                    }
                }
            },
            {
                startTime = 1000,
                tween = { selectedLevel,
                    { alpha = 0.99 },
                    {
                        time = 1000,
                        onComplete = function()
                            composer.gotoScene("WebPG.scenes.level")
                        end
                    }
                }
            }
        },
    })
    newTimeline:resume()
end

function slideOutLevel()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 0,
                tween = { btnGroup,
                    { alpha = 0,xScale = 0.01,yScale = 0.01,x = _CX, y=_CY }, 
                    { 
                        time = 1000,
                    }
                } 
            },
            {
                startTime = 0,
                tween = { btnLv1,
                    { y = -100 }, 
                    { 
                        time = 500,
                        onComplete = function()
                            wholeFade()
                        end
                    }
                } 
            },
            {
                startTime = 0,
                tween = { btnLv2,
                    { y = -100 }, 
                    { 
                        time = 600,
                    }
                } 
            },
            {
                startTime = 0,
                tween = { btnLv3,
                    {  y = -100 }, 
                    { 
                        time = 700,
                    }
                } 
            },
            {
                startTime = 0,
                tween = { btnLv4,
                    {  y = -100 }, 
                    { 
                        time = 800,
                    }
                } 
            },
            {
                startTime = 0,
                tween = { btnLv5,
                    {  y = -100 }, 
                    { 
                        time = 900,

                    }
                } 
            },
        },
    })
    newTimeline:resume()
end

function slideBackground()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 1000,
                tween = { b1,
                    { x = -1088 + display.contentWidth },
                    {
                        time = 10000,
                    }
                }
            },
            {
                startTime = 12000,
                tween = { b1,
                    { x = 0 },
                    {
                        time = 10000,
                        onComplete = function()
                            slideBackground()
                        end
                    }
                } 
            },
        },
    })
    newTimeline:resume()
end

function fadeInFadeOutTap()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 0,
                tween = { btnStart,
                    { alpha = 0 }, 
                    { 
                        time = 500,
                    }
                } 
            },
            {
                startTime = 500,
                tween = { btnStart,
                    { alpha = 1}, 
                    { 
                        time = 500,
                        onComplete = function()
                            if hasTapped == 0 then
                                fadeInFadeOutTap()
                            end
                        end
                    }
                } 
            },
        },
    })
    newTimeline:resume()
end

function slidingMessage()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime =  0,
                tween = { scrollingMessage,
                    { x = -100 }, 
                    { 
                        time = 6000,
                        onComplete = function()
                            scrollingMessage.x = _CX * 3
                            slidingMessage()
                        end,
                    }
                }   
            }
        },
    })
    newTimeline:resume()
end

-- -----------------------------------------
-- Scene event functions
-- -----------------------------------------

-- create()
function scene:create(event)
    print("scene:create - menu")

    -- Create main group and insert
    grpMain = display.newGroup()
    self.view:insert(grpMain)
    grpMain.alpha = 1
    btnGroup = display.newGroup()

    -- Insert objects to grpMain here
    local font = "WebPG/assets/font/Minecraftia-Regular.ttf"
    
    if myData.played == nil then
        myData.played = 0
    end

    -- Background
    b1 = display.newImageRect(grpMain,"WebPG/assets/images/background5.png",1088,display.contentHeight)
    b1.anchorX = 0
    b1.anchorY = 0
    b1.x = -350
    b1.fill.effect = "filter.blurGaussian"
    b1.fill.effect.horizontal.blurSize = 50
    b1.fill.effect.horizontal.sigma = 200
    b1.fill.effect.vertical.blurSize = 50
    b1.fill.effect.vertical.sigma = 200

    --

    if currentLevel < 5 then
        levelSuggestion = display.newImage(grpMain,"WebPG/assets/images/currentLevel.png",360,100)
        levelSuggestion.x = _CX
        levelSuggestion.y = (_CY*(currentLevel+1)/4) - 15
        levelSuggestion.alpha = 0
        scrollingMessage = display.newText(grpMain,"Niveau actuel",_CX*3,levelSuggestion.y+30,font,20)
        scrollingMessage.alpha = 0
    end

    select = display.newText(btnGroup,"Séléctionner un niveau",_CX,-_CY,font,20)
    btnLv1 = display.newText(btnGroup,"Tutoriel",_CX,-_CY,font,30)
    btnLv2 = display.newText(btnGroup,"Erreur",_CX,-_CY,font,30)
    btnLv3 = display.newText(btnGroup,"Authentification",_CX,-_CY,font,30)
    btnLv4 = display.newText(btnGroup,"Interaction simple",_CX,-_CY,font,30)
    btnLv5 = display.newText(btnGroup,"Quitter le jeu",_CX,-_CY,font,30)
    local btnList = {select,btnLv1,btnLv2,btnLv3,btnLv4,btnLv5}
    for i = 1,#btnList,1 do
        btnList[i].alpha = 0
        if i > myData.level+1 and btnList[i] ~= btnLv5 then
            btnList[i]:setFillColor(0.5,0.5,0.5)
        end
    end
    
    selectedLevel = display.newText("",display.contentCenterX,display.contentCenterY,font,30)
    selectedLevel.alpha = 0

    if myData.played == 0 then
        logo = display.newImageRect(grpMain,"WebPG/assets/images/logo.png",200,200)
        logo:scale(1.5,1.5)
        logo.x = display.contentWidth/2
        logo.y = -300
        btnStart = display.newText(grpMain,"Taper sur l'écran !",_CX,_CY*1.5,font,20)
        btnStart.alpha = 0
        slideDownLogo()
        myData.played = 1
    else
        slideInLevel()
    end
    slideBackground()
    grpMain:insert(btnGroup)
end

-- show()
function scene:show(event)
    if(event.phase == "will") then
    elseif(event.phase == "did") then
    end
end

-- hide()
function scene:hide(event)
    if(event.phase == "will") then
        selectedLevel:removeSelf()
    elseif(event.phase == "did") then
    end
end

-- destroy()
function scene:destroy(event)
    grpMain:removeSelf()
end

-- -----------------------------------------
-- Scene event functions listeners
-- -----------------------------------------
scene:addEventListener("create",scene)
scene:addEventListener("show",scene)
scene:addEventListener("hide",scene)
scene:addEventListener("destroy",scene)
-- -----------------------------------------

return scene