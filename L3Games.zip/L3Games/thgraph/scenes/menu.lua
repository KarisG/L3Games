-- -----------------------------------------------------------------------------------
-- Import
-- -----------------------------------------------------------------------------------

local composer = require("composer")
local relayout = require("relayout")




-- -----------------------------------------------------------------------------------
-- Set variables
-- -----------------------------------------------------------------------------------

-- Layout
local _W, _H, _CX, _CY = relayout._W, relayout._H, relayout._CX, relayout._CY

-- Scene
local scene = composer.newScene()

-- Groups
local grpMain

local text
local background
local title1
local title2
local playButton
local quitButton
local backgroundsound 
local myRoundedRect

-- -----------------------------------------------------------------------------------
-- fonctions
-- -----------------------------------------------------------------------------------
local function gotoGame()
  composer.gotoScene( "thgraph.scenes.game1" )
end

local function quit()
  composer.gotoScene("scenes.menu")
end

-- -----------------------------------------------------------------------------------
-- Scene event functions
-- -----------------------------------------------------------------------------------

----------------------------------------------
----PLAY----------
function scene:create( event )

  -- Insert objects to grpMain here
  grpMain = display.newGroup()
  self.view:insert(grpMain)

  background = display.newImageRect( grpMain,"thgraph/assets/images/background.png",display.contentWidth, display.contentHeight )
  background.x = display.contentCenterX
  background.y = display.contentCenterY


  title1 = display.newImageRect(grpMain,"thgraph/assets/images/icon_frog.png" , 120, 120)
  title1.x = 100
  title1.y = 350

  title2 = display.newImageRect(grpMain,"thgraph/assets/images/titre-1.png" , 300,150 )
  title2.x = 180
  title2.y = 150


  playButton = display.newText( grpMain, "Play", 260, 350, native.systemFont, 44 )
  playButton:setFillColor( 0.8, 0.8, 1 )
  playButton:addEventListener( "tap", gotoGame )
  
  quitButton = display.newText( grpMain, "Quit", 260, playButton.y + 60, native.systemFont, 44 )
  quitButton:setFillColor( 0.8, 0.8, 1 )
  quitButton:addEventListener( "tap", quit )
end 
  


-- show()
function scene:show( event )
  if ( event.phase == "will" ) then
  elseif ( event.phase == "did" ) then
  end
end



-- hide()
function scene:hide( event )
  if ( event.phase == "will" ) then
  elseif ( event.phase == "did" ) then
  end
end



-- destroy()
function scene:destroy(event)
  grpMain:removeSelf()
end



-- -----------------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- -----------------------------------------------------------------------------------

return scene
