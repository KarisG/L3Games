-- -----------------------------------------------------------------------------------
-- Import
-- -----------------------------------------------------------------------------------

local composer = require("composer")
local relayout = require("relayout")

-- -----------------------------------------------------------------------------------
-- Set variables
-- -----------------------------------------------------------------------------------

-- Layout
local _W, _H, _CX, _CY = relayout._W, relayout._H, relayout._CX, relayout._CY

-- Scene
local scene = composer.newScene()

-- Groups
local grpMain
local grpUI
local grpWorld

----maps---
local level3

local frog 
local background
local wood 

---Quizz----
local quiz1


local rep1
local rep2
local rep3
local rep4

local backgroundsound 
local myRoundedRect
local message
local mauvaiseRep

-- pos
local origineX
local origineY
local taille

-- btn
local btnRight
local btnDown
local btnLeft
local btnUp
local btnExit

-- coord
local x
local y

-- image
local img1
local img2
local img3
local img4

function exit(event)
  if(event.phase == "began")then
    composer.gotoScene("thgraph.scenes.menu")
  end
end

function show(event)
  if(event.phase == "began")then
    if(event.target == rep1)then
      img1.alpha = 1
    elseif(event.target == rep2)then
      img2.alpha = 1
    elseif(event.target == rep3)then
      img3.alpha = 1
    elseif(event.target == rep4)then
      img4.alpha = 1
    end
  end
end

function hide(event)
  if(event.phase == "began")then
    if(event.target == img1)then
      img1.alpha = 0
    elseif(event.target == img2)then
      img2.alpha = 0
    elseif(event.target == img3)then
      img3.alpha = 0
    elseif(event.target == img4)then
      img4.alpha = 0
    end
  end
end

function setRepPos()
  for i = 1  , 8 , 1 do 
    for j = 1 , 8 , 1 do 
      if level3[i][j] == 2 then -- Rep 1
        rep1.x =  origineX + taille * (j-1)
        rep1.y = origineY + taille * (i-1)
      elseif level3[i][j] == 3 then -- Rep 2
        rep2.x =  origineX + taille * (j-1)
        rep2.y = origineY + taille * (i-1)
      elseif level3[i][j] == 4 then -- Rep 3
        rep3.x =  origineX + taille * (j-1)
        rep3.y = origineY + taille * (i-1)
      elseif level3[i][j] == 5 then -- Rep 4
        rep4.x =  origineX + taille * (j-1)
        rep4.y = origineY + taille * (i-1)
      end  
    end 
  end
end

function updateTile()
  for i = 1  , 8 , 1 do 
    for j = 1 , 8 , 1 do 
      if level3[i][j] == 9 then
        x = i
        y = j
        frog.x = origineX + taille * (j-1)
        frog.y = origineY + taille * (i-1)
      end  
    end 
  end
end

function move(event)
  if(event.phase == "began")then
    if(event.target == btnRight)then
      if(y+1 < 9)then -- Check border limit
        if(level3[x][y+1] == 1)then -- Check available path
          level3[x][y+1] = 9
          level3[x][y] = 1
          y = y+1
          mauvaiseRep.alpha = 0
        elseif(level3[x][y+1] == 0)then
          mauvaiseRep.alpha = 0
        else
          mauvaiseRep.alpha = 1
        end
      end
    elseif(event.target == btnDown)then
      if(x+1 < 9)then 
        if(level3[x+1][y] == 1)then
          level3[x+1][y] = 9
          level3[x][y] = 1
          x = x+1
          mauvaiseRep.alpha = 0
        elseif(level3[x+1][y] == 3)then
          composer.removeScene("thgraph.scenes.game3")
          composer.gotoScene("thgraph.scenes.menu")
        else
          mauvaiseRep.alpha = 0
        end
      end
    elseif(event.target == btnLeft)then
      if(y-1 > 0)then
        if(level3[x][y-1] == 1)then
          level3[x][y-1] = 9
          level3[x][y] = 1
          y = y-1
          mauvaiseRep.alpha = 0
        elseif(level3[x][y-1] == 3)then
          composer.removeScene("thgraph.scenes.game3")
          composer.gotoScene("thgraph.scenes.menu")
        elseif(level3[x][y-1] == 0)then
          mauvaiseRep.alpha = 0
        else
          mauvaiseRep.alpha = 1
        end
      end
    elseif(event.target == btnUp)then
      if(x-1 > 0)then
        if(level3[x-1][y] == 1)then
          level3[x-1][y] = 9
          level3[x][y] = 1
          x = x-1
          mauvaiseRep.alpha = 0
        elseif(level3[x-1][y] == 3)then
          composer.removeScene("thgraph.scenes.game3")
          composer.gotoScene("thgraph.scenes.menu")
        elseif(level3[x-1][y] == 0)then
          mauvaiseRep.alpha = 0
        else
          mauvaiseRep.alpha = 1
        end
      end
    end
    updateTile()
  end
end

-- -----------------------------------------------------------------------------------
-- Scene event functions
-- -----------------------------------------------------------------------------------

-- create()
function scene:create( event )
  print("scene:create - game3")

  -- Create main group and insert to scene
  grpMain = display.newGroup()
  grpUI = display.newGroup()
  grpWorld = display.newGroup()
  grpMain:insert(grpWorld)
  grpMain:insert(grpUI)
  self.view:insert(grpMain)

  -- Insert objects to grpMain here

  wood = display.newImageRect( grpWorld,"thgraph/assets/images/wood.png",800,571 )
  wood.x = display.contentCenterX
  wood.y = display.contentCenterY
  wood:scale(2,2)



  background = display.newImageRect( grpWorld,"thgraph/assets/images/map3.png",display.contentWidth, display.contentWidth )
  background.x = display.contentCenterX
  background.y = display.contentCenterY

  level3={{0,1,1,1,1,0,0,0},
          {9,1,0,3,1,1,2,0},
          {0,1,1,1,0,1,0,0},
          {1,1,0,0,0,0,0,0},
          {1,0,0,0,1,0,1,0},
          {1,1,0,0,0,0,0,0},
          {0,1,1,1,1,1,0,0},
          {4,1,1,0,0,1,1,5}}

  origineX = background.x - background.width/2 + 24 --Columns
  origineY = background.y - background.width/2 + 24 --Lines
  taille = display.contentWidth/8

  quiz1 = display.newText(grpUI,"Qu'est ce que le degré d'un sommet?",180, origineY-60, native.systemFont, 20 )
  quiz1:setFillColor( 1, 1, 1 )

  rep1 = display.newRect( grpUI,0,0, taille,taille )
  rep1:setFillColor(1,0,0)
  rep1.alpha=0.1
  rep1:addEventListener("touch",show)

  rep2 = display.newRect( grpUI,0,0, taille,taille )
  rep2:setFillColor(0,1,0)
  rep2.alpha=0.1
  rep2:addEventListener("touch",show)

  rep3 = display.newRect( grpUI,0,0, taille,taille )
  rep3:setFillColor(0,0,1)
  rep3.alpha=0.1
  rep3:addEventListener("touch",show)

  rep4 = display.newRect( grpUI,0,0, taille,taille )
  rep4:setFillColor(1,1,1)
  rep4.alpha=0.1
  rep4:addEventListener("touch",show)

  btnRight = display.newImageRect(grpUI,"thgraph/assets/images/right.png",taille*1.5,taille*1.5)
  btnRight.x = display.contentWidth/5
  btnRight.y = display.contentHeight*4/5
  btnRight:addEventListener("touch",move)
  btnDown = display.newImageRect(grpUI,"thgraph/assets/images/down.png",taille*1.5,taille*1.5)
  btnDown.x = display.contentWidth*2/5
  btnDown.y = display.contentHeight*4/5
  btnDown:addEventListener("touch",move)
  btnLeft = display.newImageRect(grpUI,"thgraph/assets/images/left.png",taille*1.5,taille*1.5)
  btnLeft.x = display.contentWidth*3/5
  btnLeft.y = display.contentHeight*4/5
  btnLeft:addEventListener("touch",move)
  btnUp = display.newImageRect(grpUI,"thgraph/assets/images/up.png",taille*1.5,taille*1.5)
  btnUp.x = display.contentWidth*4/5
  btnUp.y = display.contentHeight*4/5
  btnUp:addEventListener("touch",move)
  btnExit = display.newText(grpUI,"X",50,50,default,50)
  btnExit:addEventListener("touch",exit)

  frog = display.newImageRect( grpWorld,"thgraph/assets/images/icon_frog.png",taille,taille )

  img1 = display.newImage(grpUI,"thgraph/assets/images/map3rep1.png",display.contentWidth,display.contentWidth)
  img1.x = display.contentCenterX
  img1.y = display.contentCenterY
  img1.alpha = 0
  img1:addEventListener("touch",hide)

  img2 = display.newImage(grpUI,"thgraph/assets/images/map3rep2.png",display.contentWidth,display.contentWidth)
  img2.x = display.contentCenterX
  img2.y = display.contentCenterY
  img2.alpha = 0
  img2:addEventListener("touch",hide)

  img3 = display.newImage(grpUI,"thgraph/assets/images/map3rep3.png",display.contentWidth,display.contentWidth)
  img3.x = display.contentCenterX
  img3.y = display.contentCenterY
  img3.alpha = 0
  img3:addEventListener("touch",hide)
  
  img4 = display.newImage(grpUI,"thgraph/assets/images/map3rep4.png",display.contentWidth,display.contentWidth)
  img4.x = display.contentCenterX
  img4.y = display.contentCenterY
  img4.alpha = 0
  img4:addEventListener("touch",hide)

  mauvaiseRep = display.newText(grpUI,"MAUVAISE REPONSE",display.contentCenterX,display.contentCenterY,default,30)
  mauvaiseRep:setFillColor(1,0,0)
  mauvaiseRep.alpha = 0
  setRepPos()
  updateTile()

end



-- show()
function scene:show( event )
  if ( event.phase == "will" ) then
  elseif ( event.phase == "did" ) then
  end
end



-- hide()
function scene:hide( event )
  if ( event.phase == "will" ) then
  elseif ( event.phase == "did" ) then
  end
end



-- destroy()
function scene:destroy(event)
  rep1:removeEventListener("touch",show)
  rep2:removeEventListener("touch",show)
  rep3:removeEventListener("touch",show)
  rep4:removeEventListener("touch",show)
  img1:removeEventListener("touch",hide)
  img2:removeEventListener("touch",hide)
  img3:removeEventListener("touch",hide)
  img4:removeEventListener("touch",hide)
  btnDown:removeEventListener("touch",move)
  btnUp:removeEventListener("touch",move)
  btnLeft:removeEventListener("touch",move)
  btnRight:removeEventListener("touch",move)
  btnExit:removeEventListener("touch",exit)
  grpUI:removeSelf()
  grpWorld:removeSelf()
  grpMain:removeSelf()
end



-- -----------------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- -----------------------------------------------------------------------------------

return scene