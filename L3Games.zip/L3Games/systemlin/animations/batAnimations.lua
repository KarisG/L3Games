module(...)

function getSequenceData()
	local sequenceData = {
		{
			name = "watch-l",
			frames = {1,5,2},
			time = 5000,
			loopCount = 0
		},
		{
			name = "watch-r",
			frames = {3,5,4},
			time = 5000,
			loopCount = 0
		},
		{
			name = "watch",
			frames = {5},
			time = 500,
			loopCount = 0
		}
	}

	return sequenceData

end