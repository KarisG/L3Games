module (...)

function getSpriteSheetData()
	
	local options = 
	{
		frames = 
		{
			-- FRAME 1
			{
				x = 0,
				y = 0,
				width = 133,
				height = 186
			},
			--FRAME 2
			{
				x = 133,
				y = 0,
				width = 133,
				height = 186
			},
			--FRAME 3
			{
				x = 266,
				y = 0,
				width = 133,
				height = 186
			},
			--FRAME 4
			{
				x = 0,
				y = 186,
				width = 133,
				height = 186
			},
			--FRAME 5
			{
				x = 133,
				y = 186,
				width = 133,
				height = 186
			},
		},
	}

	return options
end