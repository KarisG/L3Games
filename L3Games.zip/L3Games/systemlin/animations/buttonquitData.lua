module (...)

function getSpriteSheetData()
	
	local options = 
	{
		frames = 
		{
			-- FRAME 1
			{
				x = 0,
				y = 0,
				width = 32,
				height = 32
			},
			--FRAME 2
			{
				x = 0,
				y = 32,
				width = 32,
				height = 32
			},
		},
	}

	return options
end