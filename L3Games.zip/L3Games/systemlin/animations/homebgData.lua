module (...)

function getSpriteSheetData()
	
	local options = 
	{
		frames = 
		{
			-- FRAME 1
			{
				x = 0,
				y = 0,
				width = 150,
				height = 150
			},
			--FRAME 2
			{
				x = 150,
				y = 0,
				width = 150,
				height = 150
            },
            --FRAME 3
            {
                x = 300,
                y = 0,
                width = 150,
                height = 150
            },
            --FRAME 4
            {
                x = 0,
                y = 150,
                width = 150,
                height = 150
            },
            --FRAME 5
            {
                x = 150,
                y = 150,
                width = 150,
                height = 150
            },
            --FRAME 6
            {
                x = 300,
                y = 150,
                width = 150,
                height = 150
            },
            --FRAME 7
            {
                x = 0,
                y = 300,
                width = 150,
                height = 150
            },
            --FRAME 8
            {
                x = 150,
                y = 300,
                width = 150,
                height = 150
            },
            --FRAME 9
            {
                x = 300,
                y = 300,
                width = 150,
                height = 150
            },
            --FRAME 10
            {
                x = 0,
                y = 450,
                width = 150,
                height = 150
            },
            --FRAME 11
            {
                x = 150,
                y = 450,
                width = 150,
                height = 150
            },
		},
	}
	return options
end