module(...)

function getSequenceData()
	local sequenceData = {
		{
			name = "walk",
			frames = {1},
			time = 100,
			loopCount = 0
		},
		{
			name = "walk-l",
			frames = {2,3},
			time = 300,
			loopCount = 0
		},
		{
			name = "walk-r",
			frames = {4,5},
			time = 300,
			loopCount = 0
		}
	}

return sequenceData

end