module(...)

function getSequenceData()
	local sequenceData = {
		{
			name = "quit",
			frames = {1,2},
			time = 700,
			loopCount = 0
		},
	}

return sequenceData

end