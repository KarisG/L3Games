local mydata = require "systemlin.myData"

message = {}

local font = ('systemlin/assets/fonts/NovaFlat-Regular.ttf')
local text
local quitSheetData = require("systemlin.animations.buttonquitData")
local quitSeqData = require("systemlin.animations.buttonquitAnimations")

local sheetOptions = quitSheetData.getSpriteSheetData() -- Coordonnées des images
local walkingquit = quitSeqData.getSequenceData() --Les images qui vont entre elles, avec quel timing
local quitSpritesheet = graphics.newImageSheet("systemlin/assets/images/buttonquit.png", sheetOptions) -- Chargement de plusieurs image ( de coordonnées provenant de SheetOptions) depuis 1 seul fichier image (character2.png)

function message.MessageLevel2()
	local uiGroup = display.newGroup()  -- Display group for UI objects
	local black_box = display.newRect(uiGroup,0,0,display.contentWidth,display.contentHeight)
	black_box.x = display.contentCenterX
	black_box.y = display.contentCenterY
	black_box:setFillColor(0)
	black_box.alpha = 0.8

	local white_box = display.newRect(uiGroup,0,-800,800,400)
	transition.to(white_box, {time=800, y=display.contentCenterY})
	local blue_box = display.newRect(uiGroup,180,-800,370,370)
	blue_box:setFillColor(0,0,1)
	transition.to(blue_box, {time=800, y=display.contentCenterY})
	local black2_box = display.newRect(uiGroup,180,-800,350,350)
	black2_box:setFillColor(0)
	transition.to(black2_box, {time=800, y=display.contentCenterY})

	-- Text to show   
	text = display.newText( uiGroup, "Niveau 3 : Réussi !", 0, 0, font, 12)
	transition.to(text, {time=1000, x=display.contentCenterX, y=display.contentCenterY-150})
	text = display.newText( uiGroup, "Dans ce niveau, tu vas connaître tout ce qu'il y a à savoir", 0, 0, font, 12)
	transition.to(text, {time=1000, x=display.contentCenterX, y=display.contentCenterY-130})
	text = display.newText( uiGroup, " sur ce qu'il faut faire pour calculer, les signaux d'entrées", 0,0, font, 12)
	text:setFillColor(1,0,0)
	transition.to(text, {time=1000, x=display.contentCenterX, y=display.contentCenterY-120})
	text = display.newText( uiGroup, "et utiliser la transformée de Laplace pour avoir les avoir", 0,0, font, 12)
	transition.to(text, {time=1000, x=display.contentCenterX, y=display.contentCenterY-110})
	text = display.newText( uiGroup, "en sortie. Tu sauras ce qu'il faut majoritairement pour les examens !", 0,0, font, 12)
	transition.to(text, {time=1000, x=display.contentCenterX, y=display.contentCenterY-100})
	text = display.newImageRect(uiGroup, "systemlin/assets/images/tableau2.png",120,120)
	transition.to(text, {time=1000, x=display.contentCenterX-100, y=display.contentCenterY-10})
	text = display.newImageRect(uiGroup, "systemlin/assets/images/tableau3.png",180,120)
	transition.to(text, {time=1000, x=display.contentCenterX+60, y=display.contentCenterY-10})
	text = display.newImageRect(uiGroup, "systemlin/assets/images/tableau4.png",180,120)
	transition.to(text, {time=1000, x=display.contentCenterX+60, y=display.contentCenterY+110})

	local quit_button = display.newSprite(quitSpritesheet, walkingquit)
	uiGroup:insert(quit_button)
	quit_button.x = display.contentCenterX - 140
	quit_button.y = display.contentCenterY - 240
	quit_button:scale(1.5,1.5)
	quit_button:setSequence("quit")
	quit_button:play()
	quit_button:addEventListener("tap",function()
		uiGroup:removeSelf()
		mydata.level = 3
	end)
end

return message