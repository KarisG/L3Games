--Require

local composer = require( "composer" )
local mydata = require "systemlin.myData"
local message1 = require "systemlin.MessageLevel1"
local message2 = require "systemlin.MessageLevel2"
local message3 = require "systemlin.MessageLevel3"
local characterSheetData = require("systemlin.animations.characterData")
local characterSeqData = require("systemlin.animations.characterAnimations")
local batSheetData = require("systemlin.animations.batData")
local batSeqData = require("systemlin.animations.batAnimations")
local physics = require("physics")


local scene = composer.newScene()

local font = ('systemlin/assets/fonts/BigSpace-rPKx.ttf')

-- Variables
local sheetOptions = characterSheetData.getSpriteSheetData() -- Coordonnées des images
local walkingCharacter = characterSeqData.getSequenceData() --Les images qui vont entre elles, avec quel timing
local characterSpritesheet = graphics.newImageSheet("systemlin/assets/images/charactersp.png", sheetOptions) -- Chargement de plusieurs image ( de coordonnées provenant de SheetOptions) depuis 1 seul fichier image (character2.png)
local sheetOptions2 = batSheetData.getSpriteSheetData()
local walkingBat = batSeqData.getSequenceData()
local batSpritesheet = graphics.newImageSheet("systemlin/assets/images/batmanoff.png", sheetOptions2)
local isDodging
local isDodging2
local isDodging3
local balls 
local balls2
local balls3
local canAddballs
local level
local lives
local died
local livesText
local scoreText
local direction
local dispGroup
local uiGroup
local character
local batman

--Background

local background3
local background2
local background


-- Functions

-- Check collision

local function checkCollision(obj1, obj2)

	local left = (obj1.contentBounds.xMin) <= obj2.contentBounds.xMin and (obj1.contentBounds.xMax) >= obj2.contentBounds.xMin
	local right = (obj1.contentBounds.xMin) >= obj2.contentBounds.xMin and (obj1.contentBounds.xMin) <= obj2.contentBounds.xMax
	local top = (obj1.contentBounds.yMin) <= obj2.contentBounds.xMin and (obj1.contentBounds.yMax) >= obj2.contentBounds.yMin
	local bottom = (obj1.contentBounds.yMin) >= obj2.contentBounds.xMin and (obj1.contentBounds.yMin) <= obj2.contentBounds.yMax

	return (left or right) and (top or bottom)
end



-- Add balls
local function addBalls()
		local yPos = math.random(-100,0)
		local xPos = math.random(10,300)
		local newPlat = display.newImageRect(dispGroup, "systemlin/assets/images/attack.png",70,70)
		newPlat.type = "brown_balls"
		newPlat.x = xPos
		newPlat.y = yPos
		physics.addBody(newPlat,"dynamic")
		balls[#balls+1] = newPlat --Ajoute newPlat au tableau de taille #balls

		--Take it
		if mydata.score >= 25 then
			if mydata.score%25 == 0 then
				local yPos_takethis = math.random(-100,0)
				local xPos_takethis = math.random(10,300)
				local newTake = display.newImageRect(dispGroup, "systemlin/assets/images/level1rep.png",70,70)
				newTake.type = "green_balls"
				newTake.x = xPos_takethis
				newTake.y = yPos_takethis
				physics.addBody(newTake,"dynamic")
				balls[#balls+1] = newTake --Ajoute newPlat au tableau de taille #balls
			end
		end
end

local function addBalls1()
		local yPos = math.random(-100,0)
		local xPos = math.random(10,300)
		local newPlat = display.newImageRect(dispGroup,"systemlin/assets/images/attack2.png",70,70)
		newPlat.type = "white_balls"
		newPlat.x = xPos
		newPlat.y = yPos
		physics.addBody(newPlat,"dynamic")
		balls2[#balls2+1] = newPlat --Ajoute newPlat au tableau de taille #balls

		--Take it
		if mydata.score >= 50 then
			if mydata.score%50 == 0 then
				local yPos_takethis = math.random(-100,0)
				local xPos_takethis = math.random(10,300)
				local newTake = display.newImageRect(dispGroup, "systemlin/assets/images/level1rep.png",70,70)
				newTake.type = "green_balls"
				newTake.x = xPos_takethis
				newTake.y = yPos_takethis
				physics.addBody(newTake,"dynamic")
				balls2[#balls2+1] = newTake --Ajoute newPlat au tableau de taille #balls
			end
		end
end

local function addBalls2()
		local yPos = math.random(-100,0)
		local xPos = math.random(10,300)
		local newPlat = display.newImageRect(dispGroup, "systemlin/assets/images/attack3.png",80,80)
		newPlat.type = "white_balls"
		newPlat.x = xPos
		newPlat.y = yPos
		physics.addBody(newPlat,"dynamic")
		balls3[#balls3+1] = newPlat --Ajoute newPlat au tableau de taille #balls

		--Take it
		if mydata.score >= 50 then
			if mydata.score%50 == 0 then
				local yPos_takethis = math.random(-100,0)
				local xPos_takethis = math.random(10,300)
				local newTake = display.newImageRect(dispGroup, "systemlin/assets/images/level1rep.png",70,70)
				newTake.type = "green_balls"
				newTake.x = xPos_takethis
				newTake.y = yPos_takethis
				physics.addBody(newTake,"dynamic")
				balls3[#balls3+1] = newTake --Ajoute newPlat au tableau de taille #balls
			end
		end
end

-- Level zero 

local function Level_Zero()
	if isDodging then
		for i = #balls, 1,-1 do
			local object = balls[i]
			object:translate(0,2)
			if object.y > (background.y * 2) - 50 then --Si ça sort de l'écran vers le bas, je le fais disparaitre
				local child = table.remove(balls,i)

				if child ~= nil then
					child:removeSelf()
					child = nil
				end
			end

			if checkCollision(character,object) then
				if object.type == "brown_balls" then
					lives = lives - 1
					livesText.text = "Vies: " .. lives
					local child = table.remove(balls,i)
					if child ~= nil then
						child:removeSelf()
						child = nil
					end
				elseif object.type == "green_balls" then
					isDodging = false
					message1.MessageLevel1() -- Print the lesson 1
					local child = table.remove(balls,i)
					if child ~= nil then
						child:removeSelf()
						child = nil
					end
				end
			end
		end

		if canAddBalls > 35 then
			addBalls()
			canAddBalls = 0
			mydata.score = mydata.score + 1
			scoreText.text = "Score: " .. mydata.score
		end
		canAddBalls = canAddBalls + 1
	end
end

-- Level one 

local function Level_One()
	if isDodging2 then
		for i = #balls2, 1,-1 do
			local object2 = balls2[i]
			object2:translate(0,2)
			if object2.y > (background2.y * 2) - 50 then --Si ça sort de l'écran vers le bas, je le fais disparaitre
				local child = table.remove(balls2,i)
				if child ~= nil then
					child:removeSelf()
					child = nil
				end
			end

			if checkCollision(character,object2) then
				if object2.type == "white_balls" then
					lives = lives - 1
					livesText.text = "Vies: " .. lives
					local child = table.remove(balls2,i)
					if child ~= nil then
						child:removeSelf()
						child = nil
					end
				elseif object2.type == "green_balls" then
					isDodging2 = false
					message2.MessageLevel2()
					local child = table.remove(balls2,i)
					if child ~= nil then
						child:removeSelf()
						child = nil
					end
				end
			end
		end

		if canAddBalls > 24 then
			addBalls1()
			canAddBalls = 0
			mydata.score = mydata.score + 1
			scoreText.text = "Score: " .. mydata.score
		end
		canAddBalls = canAddBalls + 1
	end
end

-- Second level
local function Level_Two()
	if isDodging3 then
		batman:play()
		for i = #balls3, 1,-1 do
			local object3 = balls3[i]
			object3:translate(0,2)
			if object3.y > (background3.y * 2) - 50 then --Si ça sort de l'écran vers le bas, je le fais disparaitre
				local child = table.remove(balls3,i)
				if child ~= nil then
					child:removeSelf()
					child = nil
				end
			end

			if checkCollision(character,object3) then
				if object3.type == "white_balls" then
					lives = lives - 1
					livesText.text = "Vies: " .. lives
					local child = table.remove(balls3,i)
					if child ~= nil then
						child:removeSelf()
						child = nil
					end
				elseif object3.type == "green_balls" then
					isDodging3 = false
					message3.MessageLevel2()
					local child = table.remove(balls3,i)
					if child ~= nil then
						child:removeSelf()
						child = nil
					end
				end
			end
		end

		if canAddBalls > 17 then
			addBalls2()
			canAddBalls = 0
			mydata.score = mydata.score + 1
			scoreText.text = "Score: " .. mydata.score
		end
		canAddBalls = canAddBalls + 1
	end
end

-- Character's deplacement

local function moveCharacter(event)
	--local character = event.target
	local phase = event.phase
    if ( "began" == phase ) then
	    -- Set touch focus on the ship
	    display.currentStage:setFocus(character)
	    -- Store initial offset position
		character.touchOffsetX = event.x - character.x
    elseif ( "moved" == phase ) then
		-- Move the ship to the new touch position
		if event.x - character.touchOffsetX > character.width/2 and event.x - character.touchOffsetX < display.contentWidth - character.width/2 then
			local record_x = character.x
			character.x = event.x - character.touchOffsetX
			if record_x > character.x then
				if direction == "right" then
					character:setSequence("walk-l")
					if level == 2 then
						batman:setSequence("watch-l")
						batman:play()
					end
				end
				direction = "left"
			else
				if direction == "left" then
					character:setSequence("walk-r")
					if level == 2 then
						batman:setSequence("watch-r")
						batman:play()
					end
				end
				direction = "right"
			end
	    	character:play()
		end
    elseif ( "ended" == phase or "cancelled" == phase ) then
        -- Release touch focus on the ship
    	character:play()
		display.currentStage:setFocus( nil )
        character:setSequence("walk")
        batman:setSequence("watch")
		batman:play()
    end
end

-- Update and levels

local function update()
	if lives > 0 then
		if level == 0 then
			if mydata.level == 1 then
				level = level + 1
			else
				Level_Zero()
			end
		elseif level == 1 then
			if mydata.level == 2 then
				level = level + 1
			elseif background.y < (display.contentCenterY * 3) then
				background.y = background.y + 3
			else
				Level_One()
			end
		elseif level == 2 then
			if background2.y < (display.contentCenterY * 3) then
				background2.y = background2.y + 3
			else
				batman.x = display.contentCenterX
				batman.y = display.contentCenterY - 220
				Level_Two()
			end
		end
		if mydata.level == 3 then
			mydata.level = 0
			composer.removeScene("systemlin.scenes.game")
			composer.gotoScene("systemlin.scenes.endgame")
		end
	else
		mydata.level = 0
		composer.removeScene("systemlin.scenes.game")
		composer.gotoScene("systemlin.scenes.score")
	end
end

--------


function scene:create( event )
    local sceneGroup = self.view
    -- When the scene is first created but has not yet appeared on screen
	physics.start()
	--Background
	dispGroup = display.newGroup()
	background3 = display.newImageRect(dispGroup, "systemlin/assets/images/background3.png", display.contentWidth, display.contentHeight)
	background3.x = display.contentCenterX
	background3.y = display.contentCenterY

	background2 = display.newImageRect(dispGroup, "systemlin/assets/images/background2.png", display.contentWidth, display.contentHeight)
	background2.x = display.contentCenterX
	background2.y = display.contentCenterY

	background = display.newImageRect(dispGroup, "systemlin/assets/images/background.png", display.contentWidth, display.contentHeight)
	background.x = display.contentCenterX
	background.y = display.contentCenterY
	isDodging = true
	isDodging2 = true
	isDodging3 = true
	balls = {}
	balls2 = {}
	balls3 = {}
	canAddBalls = 0
	level = 0
	lives = 3
	mydata.score = 0
	died = false
	
	-- Text
	uiGroup = display.newGroup()    -- Display group for UI objects like the score
	livesText = display.newText( uiGroup, "Vies: " .. lives, 70, 40, font, 25 )
	scoreText = display.newText( uiGroup, "Score: " .. mydata.score, 250, 40, font, 25 )
	livesText:setFillColor(0)
	scoreText:setFillColor(0)

	-- Character and bat
	character = display.newSprite(dispGroup, characterSpritesheet, walkingCharacter)
	character:scale(0.35,0.35)
	character.type = "character"
	character.x = display.contentCenterX
	character.y = (background.y * 2) - 70
	character.touchOffsetX = 0
	character:setSequence("walk")
	character:play()

	batman = display.newSprite(dispGroup, batSpritesheet, walkingBat)
	batman.x = -500
	batman.y = -500
	batman:scale(1.5,1.5)
	self.view:insert(dispGroup)
	self.view:insert(uiGroup)
	character:addEventListener("touch", moveCharacter) -- Object method
	Runtime:addEventListener("enterFrame",update)

end
 
-- -----------------------------------------------------------------------------------
-- Code outside of the scene event functions below will only be executed ONCE unless
-- the scene is removed entirely (not recycled) via "composer.removeScene()"
-- -----------------------------------------------------------------------------------
 
-- show()
function scene:show( event )
 
    local sceneGroup = self.view
    local phase = event.phase
 
    if ( phase == "will" ) then
        -- Code here runs when the scene is still off screen (but is about to come on screen)
 
    elseif ( phase == "did" ) then
        -- Code here runs when the scene is entirely on screen
 
    end
end
 
 
-- hide()
function scene:hide( event )
 
    local sceneGroup = self.view
    local phase = event.phase
 
    if ( phase == "will" ) then
        -- Code here runs when the scene is on screen (but is about to go off screen)
 
    elseif ( phase == "did" ) then
        -- Code here runs immediately after the scene goes entirely off screen
 
    end
end
 
 
-- destroy()
function scene:destroy( event )
 
    local sceneGroup = self.view
    -- Code here runs prior to the removal of scene's view
	character:removeEventListener("touch", moveCharacter) -- Object method
	Runtime:removeEventListener("enterFrame",update)
	sceneGroup:removeSelf()
	display.currentStage:setFocus( nil )
end
 
 
-- -----------------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- -----------------------------------------------------------------------------------
 

return scene