local composer = require( "composer" )
local relayout = require("relayout")
local userData = require("userData")
local http = require("socket.http")
http.TIMEOUT = 5
local ltn12 = require("ltn12")

 local mydata = require("systemlin.myData")

 local quitSheetData = require("systemlin.animations.buttonquitData")
 local quitSeqData = require("systemlin.animations.buttonquitAnimations")
 
 local sheetOptions = quitSheetData.getSpriteSheetData() -- Coordonnées des images
 local walkingquit = quitSeqData.getSequenceData() --Les images qui vont entre elles, avec quel timing
 local quitSpritesheet = graphics.newImageSheet("systemlin/assets/images/buttonquit.png", sheetOptions) -- Chargement de plusieurs image ( de coordonnées provenant de SheetOptions) depuis 1 seul fichier image (character2.png)
 
local scene = composer.newScene()
local gameover 

local sendDataOnce
local numbers = {}

local font = ('systemlin/assets/fonts/BigSpace-rPKx.ttf')
local id = {}

-- -----------------------------------------------------------------------------------
-- Code outside of the scene event functions below will only be executed ONCE unless
-- the scene is removed entirely (not recycled) via "composer.removeScene()"
-- -----------------------------------------------------------------------------------

--Functions
local function gotoMenu()
    composer.removeScene("systemlin.scenes.score")
    composer.gotoScene("systemlin.scenes.menu")
end
 
local function updateDatabase()
    if sendDataOnce == 0 and userData.id ~= nil then
        sendDataOnce = 1
        local reqbody = "score="..mydata.score
        local respbody = {}
        local result, respcode, respheaders,respstatus = http.request {
            method = "PUT",
            url = "http://127.0.0.1:5000/updatesyst",
            source = ltn12.source.string(reqbody),
            headers = {
                ["content-type"] = "application/x-www-form-urlencoded",
                ["content-length"] = tostring(#reqbody)
            },
            body = reqbody,
            sink = ltn12.sink.table(respbody)
        }
    end
end

local function getHighscore()
    if userData.id ~= nil then
        local respbody = {}
        local result, respcode, respheaders,respstatus = http.request {
            method = "GET",
            url = "http://127.0.0.1:5000/systhighscore",
            sink = ltn12.sink.table(respbody)
        }
        numbers = {}
        for num in string.gmatch(respbody[1], "%d+") do
            numbers[#numbers + 1] = num
        end
    end
end

-- -----------------------------------------------------------------------------------
-- Scene event functions
-- -----------------------------------------------------------------------------------
 
-- create()
function scene:create( event )
 
    local sceneGroup = self.view
    -- Code here runs when the scene is first created but has not yet appeared on screen
    sendDataOnce = 0
    score = display.newText(sceneGroup, "Score: " .. mydata.score, display.contentCenterX, display.contentCenterY-50, font, 25)
    gameover = display.newText(sceneGroup, "GAME OVER ", display.contentCenterX+10, display.contentCenterY-150, font, 70)
    gameover:setFillColor(1,0,0)
    gameover = display.newText(sceneGroup, "HIGHSCORES ", display.contentCenterX+10, display.contentCenterY+50, font, 70)
    gameover:setFillColor(0,0,1)
    updateDatabase()
    local numberOfPlayer = 0
    if userData.id ~= nil then
        getHighscore()
        for i = 1, #numbers, 2 do
            if tonumber(numbers[i+1])>0 then
                numberOfPlayer = numberOfPlayer + 1
                id[i] = display.newText(sceneGroup, "Joueur : " .. numbers[i] .. "  -->  Score : " .. numbers[i+1], display.contentCenterX, display.contentCenterY+80+(50*(numberOfPlayer+1)/2), font, 25)
            end
        end
    end

    local quit_button = display.newSprite(quitSpritesheet, walkingquit)
	sceneGroup:insert(quit_button)
	quit_button.x = display.contentCenterX - 140
	quit_button.y = display.contentCenterY - 240
	quit_button:scale(1.5,1.5)
	quit_button:setSequence("quit")
	quit_button:play()
	quit_button:addEventListener("tap", gotoMenu)
end
 
 
-- show()
function scene:show( event )
 
    local sceneGroup = self.view
    local phase = event.phase
 
    if ( phase == "will" ) then
        -- Code here runs when the scene is still off screen (but is about to come on screen)
 
    elseif ( phase == "did" ) then
        -- Code here runs when the scene is entirely on screen
  
    end
end
 
 
-- hide()
function scene:hide( event )
 
    local sceneGroup = self.view
    local phase = event.phase
 
    if ( phase == "will" ) then
        -- Code here runs when the scene is on screen (but is about to go off screen)
 
    elseif ( phase == "did" ) then
        -- Code here runs immediately after the scene goes entirely off screen
 
    end
end
 
 
-- destroy()
function scene:destroy( event )
 
    local sceneGroup = self.view
    -- Code here runs prior to the removal of scene's view
    sceneGroup:removeSelf()
    score:removeSelf()
 
end
 
 
-- -----------------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- -----------------------------------------------------------------------------------
 
return scene