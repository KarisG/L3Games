local composer = require( "composer" )
local mydata = require("systemlin.myData")
local scene = composer.newScene()

local font = ('systemlin/assets/fonts/BigSpace-rPKx.ttf')

local homeSheetData = require("systemlin.animations.homebgData")
local homeSeqData = require("systemlin.animations.homebgAnimations")

local sheetOptions = homeSheetData.getSpriteSheetData() -- Coordonnées des images
local walkinghome = homeSeqData.getSequenceData() --Les images qui vont entre elles, avec quel timing
local homeSpritesheet = graphics.newImageSheet("systemlin/assets/images/home-bgoff2.png", sheetOptions) -- Chargement de plusieurs image ( de coordonnées provenant de SheetOptions) depuis 1 seul fichier image (home-bgoff.png)

local background
local playButton
local groupTest
local returnButton

local function gotoGame()
    composer.removeScene("systemlin.scenes.menu")
    composer.gotoScene("systemlin.scenes.game")
end

local function gotoMenu()
    composer.removeScene("systemlin.scenes.menu")
    composer.gotoScene("scenes.menu")
end

function scene:create( event )
 
    local sceneGroup = self.view
    -- When the scene is first created but has not yet appeared on screen
    background = display.newSprite(sceneGroup, homeSpritesheet, walkinghome)
    background.x = display.contentCenterX
    background.y = display.contentCenterY
    background:scale(2,4)
    background:setSequence("homescreen")
    background:play()

    playButton = display.newText(sceneGroup, "JOUER", 0, 0, font, 44 )
    playButton:setFillColor(0)
    returnButton = display.newText(sceneGroup,"X", 50, 50, font, 50)
    transition.to(playButton, {time=1000, x=display.contentCenterX, y=display.contentCenterY+250})

    playButton:addEventListener( "tap", gotoGame )
    returnButton:addEventListener( "tap", gotoMenu )
end
 
-- -----------------------------------------------------------------------------------
-- Code outside of the scene event functions below will only be executed ONCE unless
-- the scene is removed entirely (not recycled) via "composer.removeScene()"
-- -----------------------------------------------------------------------------------
 
-- show()
function scene:show( event )
 
    local sceneGroup = self.view
    local phase = event.phase
 
    if ( phase == "will" ) then
        -- Code here runs when the scene is still off screen (but is about to come on screen)
 
    elseif ( phase == "did" ) then
        -- Code here runs when the scene is entirely on screen
 
    end
end
 
 
-- hide()
function scene:hide( event )
 
    local sceneGroup = self.view
    local phase = event.phase
 
    if ( phase == "will" ) then
        -- Code here runs when the scene is on screen (but is about to go off screen)
 
    elseif ( phase == "did" ) then
        -- Code here runs immediately after the scene goes entirely off screen
 
    end
end
 
 
-- destroy()
function scene:destroy( event )
 
    local sceneGroup = self.view
    -- Code here runs prior to the removal of scene's view
    background:removeSelf()
end
 
-- -----------------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- -----------------------------------------------------------------------------------
 
return scene
