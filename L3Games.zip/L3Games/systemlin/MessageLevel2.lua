local mydata = require "systemlin.myData"

message = {}

local font = ('systemlin/assets/fonts/NovaFlat-Regular.ttf')
local text
local quitSheetData = require("systemlin.animations.buttonquitData")
local quitSeqData = require("systemlin.animations.buttonquitAnimations")

local sheetOptions = quitSheetData.getSpriteSheetData() -- Coordonnées des images
local walkingquit = quitSeqData.getSequenceData() --Les images qui vont entre elles, avec quel timing
local quitSpritesheet = graphics.newImageSheet("systemlin/assets/images/buttonquit.png", sheetOptions) -- Chargement de plusieurs image ( de coordonnées provenant de SheetOptions) depuis 1 seul fichier image (character2.png)

function wait(seconds)
  local start = os.time()
  repeat until os.time() > start + seconds
end

local nb = 0

function message.MessageLevel2()
	local uiGroup = display.newGroup()  -- Display group for UI objects
	local black_box = display.newRect(uiGroup,0,0,display.contentWidth,display.contentHeight)
	black_box.x = display.contentCenterX
	black_box.y = display.contentCenterY
	black_box:setFillColor(0)
	black_box.alpha = 0.8

	local white_box = display.newRect(uiGroup,0,-800,800,400)
	transition.to(white_box, {time=800, y=display.contentCenterY})
	local blue_box = display.newRect(uiGroup,180,-800,370,370)
	blue_box:setFillColor(0,0,1)
	transition.to(blue_box, {time=800, y=display.contentCenterY})
	local black2_box = display.newRect(uiGroup,180,-800,350,350)
	black2_box:setFillColor(0)
	transition.to(black2_box, {time=800, y=display.contentCenterY})

	-- Text to show   
	text = display.newText( uiGroup, "Niveau 2 : Réussi !", 0, 0, font, 12)
	transition.to(text, {time=1000, x=display.contentCenterX, y=display.contentCenterY-150})
	text = display.newText( uiGroup, "Dans ce niveau, tu vas connaître tout ce qu'il y a à savoir", 0, 0, font, 12)
	transition.to(text, {time=1000, x=display.contentCenterX, y=display.contentCenterY-130})
	text = display.newText( uiGroup, " sur la notion de système, les entrées et les sorties.", 0,0, font, 12)
	text:setFillColor(1,0,0)
	transition.to(text, {time=1000, x=display.contentCenterX, y=display.contentCenterY-120})
	text = display.newText( uiGroup, "Un système est une structure technologique qui accomplie plusieurs", 0,0, font, 12)
	transition.to(text, {time=1000, x=display.contentCenterX, y=display.contentCenterY-100})
	text = display.newText( uiGroup, "fonctions : transforme de la MATIERE, de l'ENERGIE, et REAGIT", 0,0, font, 12)
	transition.to(text, {time=1000, x=display.contentCenterX, y=display.contentCenterY-90})
	text = display.newText( uiGroup, "avec l'environnement. Il transforme un signal d'entrée e en un", 0,0, font, 12)
	transition.to(text, {time=1000, x=display.contentCenterX, y=display.contentCenterY-80})
	text = display.newText( uiGroup, "signal de sortie s (aussi appelé réponse)", 0,0, font, 12)
	transition.to(text, {time=1000, x=display.contentCenterX, y=display.contentCenterY-70})
	text = display.newText( uiGroup, "Si le signal d'entrée est un dirac δ(t), la sortie sera", 0,0, font, 12)
	transition.to(text, {time=1000, x=display.contentCenterX-40, y=display.contentCenterY-50})
	text = display.newText( uiGroup, "impulsionnelle", 0,0, font, 12)
	text:setFillColor(1,0,0)
	transition.to(text, {time=1000, x=display.contentCenterX+130, y=display.contentCenterY-50})
	text = display.newText( uiGroup, "Si le signal d'entrée est un échelon unité, la sortie sera ", 0,0, font, 12)
	transition.to(text, {time=1000, x=display.contentCenterX-20, y=display.contentCenterY-40})
	text = display.newText( uiGroup, "indicielle ", 0,0, font, 12)		
	text:setFillColor(1,0,0)
	transition.to(text, {time=1000, x=display.contentCenterX+150, y=display.contentCenterY-40})
	text = display.newImageRect(uiGroup, "systemlin/assets/images/systemeimg.png",150,150)
	transition.to(text, {time=1000, x=display.contentCenterX, y=display.contentCenterY+20})
	text = display.newText( uiGroup, "Si le signal d'entrée est à rampe, la sortie sera ", 0,0, font, 12)
	transition.to(text, {time=1000, x=display.contentCenterX-40, y=display.contentCenterY+70})
	text = display.newText( uiGroup, "à rampe ", 0,0, font, 12)		
	text:setFillColor(1,0,0)
	transition.to(text, {time=1000, x=display.contentCenterX+110, y=display.contentCenterY+70})
	text = display.newText( uiGroup, "Si le signal d'entrée est sinusoïdale, la sortie sera ", 0,0, font, 12)
	transition.to(text, {time=1000, x=display.contentCenterX-40, y=display.contentCenterY+80})
	text = display.newText( uiGroup, "harmonique ", 0,0, font, 12)		
	text:setFillColor(1,0,0)
	transition.to(text, {time=1000, x=display.contentCenterX+120, y=display.contentCenterY+80})
	text = display.newText(uiGroup, "Inévitable, à savoir par coeur :", 0,0, font, 12)
	transition.to(text, {time=1000, x=display.contentCenterX-90, y=display.contentCenterY+130})
	text = display.newImageRect(uiGroup, "systemlin/assets/images/systeme2img.png",150,150)
	transition.to(text, {time=1000, x=display.contentCenterX+60, y=display.contentCenterY+150})
	local quit_button = display.newSprite(quitSpritesheet, walkingquit)
	uiGroup:insert(quit_button)
	quit_button.x = display.contentCenterX - 140
	quit_button.y = display.contentCenterY - 240
	quit_button:scale(1.5,1.5)
	quit_button:setSequence("quit")
	quit_button:play()
	quit_button:addEventListener("tap",function()
		uiGroup:removeSelf()
		mydata.level = 2
	end)
end

return message