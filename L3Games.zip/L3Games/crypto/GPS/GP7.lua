local composer = require( "composer" )
local userData = require("userData")
local http = require("socket.http")
http.TIMEOUT = 5
local ltn12 = require("ltn12")

local scene = composer.newScene()
 
-- -----------------------------------------------------------------------------------
-- Code outside of the scene event functions below will only be executed ONCE unless
-- the scene is removed entirely (not recycled) via "composer.removeScene()"
-- -----------------------------------------------------------------------------------

local grpBackground
local grpMain
local grpUI

local backgroundImage
local messageImage
local gridQuest
local grid1
local grid2
local grid3
local grid4

local function updateDatabase()
    local reqbody = "score="..userData.crypto
    local respbody = {}
    local result, respcode, respheaders,respstatus = http.request {
        method = "PUT",
        url = "http://127.0.0.1:5000/updatecrypto",
        source = ltn12.source.string(reqbody),
        headers = {
            ["content-type"] = "application/x-www-form-urlencoded",
            ["content-length"] = tostring(#reqbody)
        },
        body = reqbody,
        sink = ltn12.sink.table(respbody)
    }
end

local function drawMessage()
    messageImage = display.newImageRect(grpMain,"crypto/images/rsa2.png", 275, 80)
    messageImage.x = display.contentCenterX
    messageImage.y = display.contentCenterY - 100
    messageImage.strokeWidth = 7
    messageImage:setStrokeColor(0,0,0)
    
end

local optionsQuestion = 
{
    text = "Crypter x grace au\n       système RSA:",     
    x = display.contentCenterX,
    y = display.contentCenterY -250,
    font = "crypto/fonts/Lobster-Regular.ttf",   
    fontSize = 35,
}

local optionsAnswer1 = 
{
    text = "14",     
    x = display.contentCenterX -100,
    y = display.contentCenterY +100,
    font = "crypto/fonts/Lobster-Regular.ttf",   
    fontSize = 40,

}

local optionsAnswer2 = 
{

    text = "12",     
    x = display.contentCenterX +100,
    y = display.contentCenterY +100,
    font = "crypto/fonts/Lobster-Regular.ttf",   
    fontSize = 40,

}

local optionsAnswer3 = 
{
    text = "8",     
    x = display.contentCenterX -100,
    y = display.contentCenterY +250,
    font = "crypto/fonts/Lobster-Regular.ttf",   
    fontSize = 40,
}

local optionsAnswer4 = 
{   
    text = "54",     
    x = display.contentCenterX +100,
    y = display.contentCenterY +250,
    font = "crypto/fonts/Lobster-Regular.ttf",   
    fontSize = 40,
}

local function whichSquareTapped(event)
    print("wp " .. event.target.number)
    if (event.target.number == 1) then
        userData.crypto = userData.crypto + 1
        if userData.id ~= nil and sendDataOnce == 0 then
            sendDataOnce = 1
            updateDatabase()
        end
    end
    composer.removeScene("crypto.GPS.GP7")
    composer.gotoScene("crypto.GPS.GP00", {time = 1000, effect="crossFade"})
end



local function drawQuiz()
    gridQuest = display.newRect(grpUI,display.contentCenterX, display.contentCenterY - 250, 350, 100)
    grid1 = display.newRect(grpUI,display.contentCenterX - 100, display.contentCenterY +100, 150, 50)
    grid2 = display.newRect(grpUI,display.contentCenterX + 100, display.contentCenterY +100, 150, 50)
    grid4 = display.newRect(grpUI,display.contentCenterX + 100, display.contentCenterY +250, 150, 50)
    grid3 = display.newRect(grpUI,display.contentCenterX - 100, display.contentCenterY +250, 150, 50)
    gridQuest.strokeWidth = 3
    grid1.strokeWidth = 3
    grid2.strokeWidth = 3
    grid3.strokeWidth = 3
    grid4.strokeWidth = 3
    gridQuest:setStrokeColor(0,0,0)
    grid1:setStrokeColor(0,0,0)
    grid2:setStrokeColor(0,0,0)
    grid3:setStrokeColor(0,0,0)
    grid4:setStrokeColor(0,0,0)
    grid1.number = 1
    grid2.number = 2
    grid3.number = 3
    grid4.number = 4
    grid1:addEventListener("tap", whichSquareTapped)
    grid2:addEventListener("tap", whichSquareTapped)
    grid3:addEventListener("tap", whichSquareTapped)
    grid4:addEventListener("tap", whichSquareTapped)

    
end

local function drawQuestion()
    local questions = display.newText( optionsQuestion )
    questions:setFillColor( 1, 0, 0 )
    questions.isVisible = true
    grpUI:insert(questions)
end
local function drawAnswer1()
    local answers = display.newText( optionsAnswer1 )
    answers:setFillColor( 0, 0, 1 )
    answers.isVisible = true
    grpUI:insert(answers)
    
end

local function drawAnswer2()
    local answers = display.newText( optionsAnswer2 )
    answers:setFillColor( 0, 0, 1 )
    answers.isVisible = true
    grpUI:insert(answers)
end

local function drawAnswer3()
    local answers = display.newText( optionsAnswer3 )
    answers:setFillColor( 0, 0, 1 )
    answers.isVisible = true
    grpUI:insert(answers)
end

local function drawAnswer4()
    local answers = display.newText( optionsAnswer4 )
    answers:setFillColor( 0, 0, 1 )
    answers.isVisible = true
    grpUI:insert(answers)
end


local function drawBackground()

    backgroundImage = display.newImageRect(grpBackground,"crypto/images/menu2.jpg", display.contentWidth, display.contentHeight)
    backgroundImage.x = display.contentCenterX
    backgroundImage.y = display.contentCenterY

end


 

 
 
 
-- -----------------------------------------------------------------------------------
-- Scene event functions
-- -----------------------------------------------------------------------------------
 
-- create()
function scene:create( event )
    
    local sceneGroup = self.view


    grpBackground = display.newGroup()  
    grpMain = display.newGroup()  --this will overlay 'farBackground'  
    grpUI = display.newGroup()  --and this will overlay 'nearBackground'
    sceneGroup:insert(grpBackground)
    sceneGroup:insert(grpMain)
    sceneGroup:insert(grpUI)
    drawQuiz()
    drawBackground()
    sendDataOnce = 0
   

    
    -- Code here runs when the scene is first created but has not yet appeared on screen
    
    
    

end
 
 
-- show()
function scene:show( event )
 
    local sceneGroup = self.view
    local phase = event.phase
 
    if ( phase == "will" ) then
        -- Code here runs when the scene is still off screen (but is about to come on screen)
        

        drawQuestion()
        drawMessage()
        drawAnswer1()
        drawAnswer2()
        drawAnswer3()
        drawAnswer4()
 
    elseif ( phase == "did" ) then
        -- Code here runs when the scene is entirely on screen
 
    end
end
 
 
-- hide()
function scene:hide( event )
 
    local sceneGroup = self.view
    local phase = event.phase
 
    if ( phase == "will" ) then
        -- Code here runs when the scene is on screen (but is about to go off screen)
 
    elseif ( phase == "did" ) then
        -- Code here runs immediately after the scene goes entirely off screen
 
    end
end
 
 
-- destroy()
function scene:destroy( event )
 
    local sceneGroup = self.view
    -- Code here runs prior to the removal of scene's view
    grid1:removeEventListener("tap", whichSquareTapped)
    grid2:removeEventListener("tap", whichSquareTapped)
    grid3:removeEventListener("tap", whichSquareTapped)
    grid4:removeEventListener("tap", whichSquareTapped) 
    grpBackground:removeSelf()
    grpMain:removeSelf()
    grpUI:removeSelf()
 
end
 
 
-- -----------------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- -----------------------------------------------------------------------------------
 
return scene