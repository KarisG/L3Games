local composer = require( "composer" )
local userData = require("userData")
local http = require("socket.http")
http.TIMEOUT = 5
local ltn12 = require("ltn12")

local scene = composer.newScene()


local grpBackground
local nextImage
local backgroundImage
local realScore

local ScoreIndi = 
{
    text = "Score: ",     
    x = display.contentCenterX -50,
    y = display.contentCenterY +175,
    font = "crypto/fonts/Lobster-Regular.ttf",   
    fontSize = 35,
}

local ScoreInd = 
{
    text = userData.crypto,     
    x = display.contentCenterX + 50,
    y = display.contentCenterY +175,
    font = "crypto/fonts/Lobster-Regular.ttf",   
    fontSize = 35,
}


local function updateDatabase()
    local reqbody = "score="..userData.crypto
    local respbody = {}
    local result, respcode, respheaders,respstatus = http.request {
        method = "PUT",
        url = "http://127.0.0.1:5000/updatecrypto",
        source = ltn12.source.string(reqbody),
        headers = {
            ["content-type"] = "application/x-www-form-urlencoded",
            ["content-length"] = tostring(#reqbody)
        },
        body = reqbody,
        sink = ltn12.sink.table(respbody)
    }
end


local function drawBackground()

    backgroundImage = display.newImageRect(grpBackground,"crypto/images/gameover.jpg", display.contentWidth, display.contentHeight)
    backgroundImage.x = display.contentCenterX
    backgroundImage.y = display.contentCenterY 

end

local function whichSquareTapped(event)
    print("wp " .. event.target.name)
    userData.crypto = 0
    composer.removeScene("crypto.GPS.GP00") 
    composer.gotoScene("crypto.GPS.GP0", {time = 1000, effect="crossFade"})
    
    
end

local function drawNextImage()

    nextImage = display.newImageRect(grpBackground,"crypto/images/buttonmenu.png", 300, 100)
    nextImage.x = display.contentCenterX
    nextImage.y = display.contentCenterY + 270
    nextImage.strokeWidth = 6
    nextImage:setStrokeColor(0,0,0)
    nextImage.name = "start"
    nextImage:addEventListener("tap", whichSquareTapped)


end




local function drawQuestion()
    local score = display.newText( ScoreIndi)
    score:setFillColor( 1, 0, 0 )
    score.isVisible = true
    grpBackground:insert(score)
    
end

local function drawScore()
    local score1 = display.newText( ScoreInd)
    score1:setFillColor( 1, 0, 0 )
    score1.isVisible = true
    grpBackground:insert(score1)
    
end





function scene:create( event )
    local sceneGroup = self.view
    realScore = userData.crypto
    userData.crypto = 0
    if userData.id ~= nil then
        updateDatabase()
    end
    userData.crypto = realScore
    grpBackground = display.newGroup()  
    -- Code here runs when the scene is first created but has not yet appeared on screen
    sceneGroup:insert(grpBackground)
    drawBackground()
    
    
 
end
 
 
-- show()
function scene:show( event )
 
    local sceneGroup = self.view
    local phase = event.phase
 
    if ( phase == "will" ) then
        -- Code here runs when the scene is still off screen (but is about to come on screen)
        drawQuestion()
        drawScore()
        drawNextImage()
        
 
    elseif ( phase == "did" ) then
        -- Code here runs when the scene is entirely on screen
 
    end
end
 
 
-- hide()
function scene:hide( event )
 
    local sceneGroup = self.view
    local phase = event.phase
 
    if ( phase == "will" ) then
        -- Code here runs when the scene is on screen (but is about to go off screen)
 
    elseif ( phase == "did" ) then
        -- Code here runs immediately after the scene goes entirely off screen
 
    end
end
 
 
-- destroy()
function scene:destroy( event )
 
    local sceneGroup = self.view
    grpBackground:removeSelf()
    
    

    
    -- Code here runs prior to the removal of scene's view
 
end
 
 
-- -----------------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- -----------------------------------------------------------------------------------
 
return scene