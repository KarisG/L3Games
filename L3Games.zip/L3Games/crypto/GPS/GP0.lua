local composer = require( "composer" )
local scene = composer.newScene()

local grpBackground
local nextImage
local backgroundImage
local retour

local function retourMenu()
    composer.removeScene("crypto.GPS.GP0")
    composer.gotoScene("scenes.menu")
end

local function drawBackground()

    backgroundImage = display.newImageRect(grpBackground,"crypto/images/menu.jpg", display.contentWidth, display.contentHeight)
    backgroundImage.x = display.contentCenterX
    backgroundImage.y = display.contentCenterY 

end

local function whichSquareTapped(event)
    print("wp " .. event.target.name)
    composer.removeScene("crypto.GPS.GP0") 
    composer.gotoScene("crypto.GPS.GP1", {time = 1000, effect="crossFade"})
end

local function drawNextImage()

    nextImage = display.newImageRect(grpBackground,"crypto/images/start.jpg", 200, 100)
    nextImage.x = display.contentCenterX
    nextImage.y = display.contentCenterY + 270
    nextImage.strokeWidth = 6
    nextImage:setStrokeColor(0,0,0)
    nextImage.name = "start"
    nextImage:addEventListener("tap", whichSquareTapped)

end

local function drawRetourImage()

    retour = display.newText(grpBackground,"EXIT",50,50,"crypto/fonts/Lobster-Regular.ttf",50)
    retour.x = 50
    retour.y = 50
    retour:addEventListener("tap",retourMenu)
end



function scene:create( event )
 
    local sceneGroup = self.view
    grpBackground = display.newGroup()  
    -- Code here runs when the scene is first created but has not yet appeared on screen
    drawBackground()
    
 
end
 
 
-- show()
function scene:show( event )
 
    local sceneGroup = self.view
    local phase = event.phase
 
    if ( phase == "will" ) then
        -- Code here runs when the scene is still off screen (but is about to come on screen)
       
        drawNextImage()
        drawRetourImage()
    elseif ( phase == "did" ) then
        -- Code here runs when the scene is entirely on screen
 
    end
end
 
 
-- hide()
function scene:hide( event )
 
    local sceneGroup = self.view
    local phase = event.phase
 
    if ( phase == "will" ) then
        -- Code here runs when the scene is on screen (but is about to go off screen)
 
    elseif ( phase == "did" ) then
        -- Code here runs immediately after the scene goes entirely off screen
 
    end
end
 
 
-- destroy()
function scene:destroy( event )
 
    local sceneGroup = self.view
    grpBackground:removeSelf()
    
    

    
    -- Code here runs prior to the removal of scene's view
 
end
 
 
-- -----------------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- -----------------------------------------------------------------------------------
 
return scene