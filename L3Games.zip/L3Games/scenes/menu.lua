--------------------------------------------
-- Import
--------------------------------------------

local composer = require("composer")
local relayout = require("relayout")
local userData = require("userData")
local animation = require("animation")
local http = require("socket.http")
http.TIMEOUT = 3
local ltn12 = require("ltn12")

local reqbody = "Yes"
local respbody = {}

-- -----------------------------------------
-- Variables
-- -----------------------------------------

-- layout
local _W, _H, _CX, _CY = relayout._W, relayout._H, relayout._CX, relayout._CY

-- Scene
local scene = composer.newScene()

-- Groups
local grpMain
local grpWorld
local grpUI


-- Display
local logo
local currentAccount

-- Buttons
local btnWebpg
local btnThSig
local btnSystLin
local btnCrypto
local btnThGraph

local btnLogin
local btnRegister
local btnLogout
local btnPlay

-- Animation
local whiteFade

-- -----------------------------------------
-- Functions
-- -----------------------------------------

function selectScene(event)
    if event.phase == "began" then
        composer.removeScene("scenes.menu")
        if event.target == btnLogin then
            userData.faded = 2
            composer.gotoScene("scenes.login")
        elseif event.target == btnRegister then
            userData.faded = 2
            composer.gotoScene("scenes.register")
        elseif event.target == btnWebpg then
            userData.faded = 1
            composer.gotoScene("WebPG.scenes.menu")
        elseif event.target == btnThSig then
            userData.faded = 1
            composer.gotoScene("TheorieSig.scenes.menu")
        elseif event.target == btnCrypto then
            userData.faded = 1
            composer.gotoScene("crypto.GPS.GP"..userData.crypto)
        elseif event.target == btnThGraph then
            userData.faded = 1
            composer.gotoScene("thgraph.scenes.menu")
        elseif event.target == btnSystLin then
            composer.gotoScene("systemlin.scenes.menu")
        end
    end
end

function logout(event)
    if event.phase == "began" then
        respbody = {}
        local result, respcode, respheaders,respstatus = http.request {
            url = "http://127.0.0.1:5000/logout",
            sink = ltn12.sink.table(respbody)
        }
        composer.removeScene("scenes.menu")
        userData.id = nil
        composer.gotoScene("scenes.login")
    end
end

function getUserData()
    if userData.id ~= nil then
        respbody = {}
        local result, respcode, respheaders,respstatus = http.request {
            method = "GET",
            url = "http://127.0.0.1:5000/data",
            sink = ltn12.sink.table(respbody)
        }
        -- Extract numbers from string response
        local numbers = {}
        for num in string.gmatch(respbody[1], "%d+") do
             numbers[#numbers + 1] = num
        end
        userData.webpg = tonumber(numbers[1])
        userData.crypto = tonumber(numbers[2])
        userData.systlin = tonumber(numbers[3])
        userData.thsignalamp = tonumber(numbers[4])
        userData.thsignalpha = tonumber(numbers[5])
        userData.thgraph = tonumber(numbers[6])
    end
end

-- Default data
function initiateData()
    userData.webpg = 1
    userData.crypto = 0
    userData.systlin = 0
    userData.thsignalamp = 0
    userData.thsignalpha = 0
    userData.thgraph = 0
end


-- -----------------------------------------
-- Animations
-- -----------------------------------------

function whiteFadeRemove()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 0,
                tween = { logo,
                    { alpha = 0 },
                    {
                        time = 1,
                    }
                }
            },
            {
                startTime = 500,
                tween = { whiteFade,
                    { alpha = 0 },
                    {
                        time = 1000,
                    }
                }
            },
        },
    })
    newTimeline:resume()
end

function rotateLogo()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 0,
                tween = { logo,
                    { xScale = 0.01,yScale = 0.01 },
                    {
                        time = 100,
                    }
                }
            },
            {
                startTime = 500,
                tween = { logo,
                    { rotation = 1440,alpha = 1,xScale = 1, yScale = 1 },
                    {
                        time = 2000,
                        onComplete = function()
                            if userData.id == nil then
                                popButtons()
                            else
                                popButtonsLoggedIn()
                            end
                        end
                    }
                }
            },
        },
    })
    newTimeline:resume()
end

function rotateOutLogo(event)
    if event.phase == "began" then
        btnPlay.alpha = 0
        if userData.id == nil then
            btnRegister.alpha = 0
            btnLogin.alpha = 0
        else
            btnLogout.alpha = 0
        end

        local newTimeline = animation.newTimeline( {
            tweens = {
                {
                    startTime = 0,
                    tween = { logo,
                        { rotation = -1440,alpha = 0.01,xScale = 0.01, yScale = 0.01 },
                        {
                            time = 1000,
                            onComplete = function()
                                logo.alpha = 0
                                popGameButtons()
                            end
                        }
                    }
                },
            },
        })
        newTimeline:resume()
    end
end

function slideDownBg()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 0,
                tween = { bg,
                    { y = -(960*(1+display.contentHeight/960) - display.contentHeight)},
                    {
                        time = 2500,
                    }
                }
            },
        },
    })
    newTimeline:resume()
end

function popButtons()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 0,
                tween = { grpUI,
                    { alpha = 1 },
                    {
                        time = 700,
                    }
                }
            },
            {
                startTime = 0,
                tween = { btnRegister,
                    { xScale = 0.01, yScale = 0.01},
                    {
                        time = 1,
                    }
                }
            },
            {
                startTime = 0,
                tween = { btnLogin,
                    { xScale = 0.01, yScale = 0.01},
                    {
                        time = 1,
                    }
                }
            },
            {
                startTime = 0,
                tween = { btnPlay,
                    { xScale = 0.01, yScale = 0.01},
                    {
                        time = 1,
                    }
                }
            },
            {
                startTime = 20,
                tween = { btnRegister,
                    { xScale = 1.2, yScale = 1.2,alpha = 1},
                    {
                        time = 400,
                    }
                }
            },
            {
                startTime = 400,
                tween = { btnLogin,
                    { xScale = 1.2, yScale = 1.2,alpha = 1},
                    {
                        time = 400,
                    }
                }
            },
            {
                startTime = 800,
                tween = { btnPlay,
                    { xScale = 1.2, yScale = 1.2,alpha = 1},
                    {
                        time = 400,
                    }
                }
            },
            {
                startTime = 400,
                tween = { btnRegister,
                    { xScale = 1, yScale = 1},
                    {
                        time = 200,
                    }
                },
            },
            {
                startTime = 800,
                tween = { btnLogin,
                    { xScale = 1, yScale = 1},
                    {
                        time = 200,
                    }
                }
            },
            {
                startTime = 1200,
                tween = { btnPlay,
                    { xScale = 1, yScale = 1},
                    {
                        time = 200,
                        onComplete = function()
                            btnPlay:addEventListener("touch",rotateOutLogo)
                        end
                    }
                }
            },
        },
    })
    newTimeline:resume()
end

function popButtonsLoggedIn()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 0,
                tween = { grpUI,
                    { alpha = 1 },
                    {
                        time = 700,
                    }
                }
            },
            {
                startTime = 0,
                tween = { btnLogout,
                    { xScale = 0.01, yScale = 0.01},
                    {
                        time = 1,
                    }
                }
            },
            {
                startTime = 0,
                tween = { btnPlay,
                    { xScale = 0.01, yScale = 0.01},
                    {
                        time = 1,
                    }
                }
            },
            {
                startTime = 400,
                tween = { btnLogout,
                    { xScale = 1.2, yScale = 1.2,alpha = 1},
                    {
                        time = 400,
                    }
                }
            },
            {
                startTime = 20,
                tween = { btnPlay,
                    { xScale = 1.2, yScale = 1.2,alpha = 1},
                    {
                        time = 400,
                    }
                }
            },
            {
                startTime = 800,
                tween = { btnLogout,
                    { xScale = 1, yScale = 1},
                    {
                        time = 200,
                        onComplete = function()
                            btnPlay:addEventListener("touch",rotateOutLogo)
                        end
                    }
                },
            },
            {
                startTime = 400,
                tween = { btnPlay,
                    { xScale = 1, yScale = 1},
                    {
                        time = 200,
                    }
                }
            },
        },
    })
    newTimeline:resume()
end

function popGameButtons()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 0,
                tween = { btnCrypto,
                    { xScale = 0.01, yScale = 0.01},
                    {
                        time = 1,
                    }
                }
            },
            {
                startTime = 0,
                tween = { btnWebpg,
                    { xScale = 0.01, yScale = 0.01},
                    {
                        time = 1,
                    }
                }
            },
            {
                startTime = 0,
                tween = { btnSystLin,
                    { xScale = 0.01, yScale = 0.01},
                    {
                        time = 1,
                    }
                }
            },
            {
                startTime = 0,
                tween = { btnThSig,
                    { xScale = 0.01, yScale = 0.01},
                    {
                        time = 1,
                    }
                }
            },
            {
                startTime = 0,
                tween = { btnThGraph,
                    { xScale = 0.01, yScale = 0.01},
                    {
                        time = 1,
                    }
                }
            },
            {
                startTime = 0,
                tween = { btnBack,
                    { xScale = 0.01, yScale = 0.01},
                    {
                        time = 1,
                    }
                }
            },
            {
                startTime = 20,
                tween = { btnCrypto,
                    { xScale = 1.2, yScale = 1.2,alpha = 1},
                    {
                        time = 400,
                    }
                }
            },
            {
                startTime = 400,
                tween = { btnWebpg,
                    { xScale = 1.2, yScale = 1.2,alpha = 1},
                    {
                        time = 400,
                    }
                }
            },
            {
                startTime = 800,
                tween = { btnSystLin,
                    { xScale = 1.2, yScale = 1.2,alpha = 1},
                    {
                        time = 400,
                    }
                }
            },
            {
                startTime = 1200,
                tween = { btnThSig,
                    { xScale = 1.2, yScale = 1.2,alpha = 1},
                    {
                        time = 400,
                    }
                }
            },
            {
                startTime = 1600,
                tween = { btnThGraph,
                    { xScale = 1.2, yScale = 1.2,alpha = 1},
                    {
                        time = 400,
                    }
                }
            },
            {
                startTime = 2000,
                tween = { btnBack,
                    { xScale = 1.2, yScale = 1.2,alpha = 1},
                    {
                        time = 400,
                    }
                }
            },
            {
                startTime = 400,
                tween = { btnCrypto,
                    { xScale = 1, yScale = 1},
                    {
                        time = 200,
                    }
                },
            },
            {
                startTime = 800,
                tween = { btnWebpg,
                    { xScale = 1, yScale = 1},
                    {
                        time = 200,
                    }
                }
            },
            {
                startTime = 1200,
                tween = { btnSystLin,
                    { xScale = 1, yScale = 1},
                    {
                        time = 200,
                    }
                }
            },
            {
                startTime = 1600,
                tween = { btnThSig,
                    { xScale = 1, yScale = 1},
                    {
                        time = 200,
                    }
                }
            },
            {
                startTime = 2000,
                tween = { btnThGraph,
                    { xScale = 1, yScale = 1},
                    {
                        time = 200,
                    }
                }
            },
            {
                startTime = 2400,
                tween = { btnBack,
                    { xScale = 1, yScale = 1},
                    {
                        time = 200,
                    }
                }
            },
        },
    })
    newTimeline:resume()
end

function popOutGameButtons()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 0,
                tween = { btnCrypto,
                    { xScale = 1.2, yScale = 1.2},
                    {
                        time = 200,
                    }
                }
            },
            {
                startTime = 0,
                tween = { btnWebpg,
                    { xScale = 1.2, yScale = 1.2},
                    {
                        time = 200,
                    }
                }
            },
            {
                startTime = 0,
                tween = { btnSystLin,
                    { xScale = 1.2, yScale = 1.2},
                    {
                        time = 200,
                    }
                }
            },
            {
                startTime = 0,
                tween = { btnThSig,
                    { xScale = 1.2, yScale = 1.2},
                    {
                        time = 200,
                    }
                }
            },
            {
                startTime = 0,
                tween = { btnThGraph,
                    { xScale = 1.2, yScale = 1.2},
                    {
                        time = 200,
                    }
                }
            },
            {
                startTime = 0,
                tween = { btnBack,
                    { xScale = 1.2, yScale = 1.2},
                    {
                        time = 200,
                    }
                }
            },
            {
                startTime = 200,
                tween = { btnCrypto,
                    { xScale = 0.01, yScale = 0.01,alpha = 0},
                    {
                        time = 400,
                    }
                }
            },
            {
                startTime = 200,
                tween = { btnWebpg,
                    { xScale = 0.01, yScale = 0.01,alpha = 0},
                    {
                        time = 400,
                    }
                }
            },
            {
                startTime = 200,
                tween = { btnSystLin,
                    { xScale = 0.01, yScale = 0.01,alpha = 0},
                    {
                        time = 400,
                    }
                }
            },
            {
                startTime = 200,
                tween = { btnThSig,
                    { xScale = 0.01, yScale = 0.01,alpha = 0},
                    {
                        time = 400,
                    }
                }
            },
            {
                startTime = 200,
                tween = { btnThGraph,
                    { xScale = 0.01, yScale = 0.01,alpha = 0},
                    {
                        time = 400,
                    }
                }
            },
            {
                startTime = 200,
                tween = { btnBack,
                    { xScale = 0.01, yScale = 0.01,alpha = 0},
                    {
                        time = 400,
                        onComplete = function()
                            rotateLogo()
                        end
                    }
                }
            }
        },
    })
    newTimeline:resume()
end

-- -----------------------------------------
-- Scene event functions
-- -----------------------------------------

-- create()
function scene:create(event)
    print("scene:create - menu")

    -- Create main group and insert
    grpMain = display.newGroup()
    grpWorld = display.newGroup()
    grpUI = display.newGroup()
    grpUI.alpha = 0
    grpMain:insert(grpWorld)
    grpMain:insert(grpUI)
    self.view:insert(grpMain)
    initiateData()
    getUserData()
    
    font = "assets/fonts/GAMERIA.ttf"
    -- World
    bg = display.newImageRect(grpWorld,"assets/images/bg.jpg",640*(1+display.contentWidth/640),960*(1+display.contentHeight/960))
    bg.anchorX = 0
    bg.anchorY = 0
    logo = display.newImageRect(grpWorld,"assets/images/logo.png",300,300)
    logo.x = display.contentWidth/2
    logo.y = display.contentHeight/4
    currentAccount = display.newText(grpWorld,"",_CX,display.contentHeight-20,font,20)

    -- UI
    height = display.contentHeight/7
    btnWebpg = display.newText(grpUI,"WebPG",_CX,height*2,font,50)
    btnWebpg:addEventListener("touch",selectScene)
    btnWebpg.alpha = 0
    btnWebpg:setFillColor(0,0,1)

    btnThSig = display.newText(grpUI,"Th Signal",_CX,height*4,font,50)
    btnThSig:addEventListener("touch",selectScene)
    btnThSig.alpha = 0
    btnThSig:setFillColor(0,0,1)

    btnSystLin = display.newText(grpUI,"Syst Lin",_CX,height*3,font,50)
    btnSystLin:addEventListener("touch",selectScene) 
    btnSystLin.alpha = 0
    btnSystLin:setFillColor(0,0,1)

    btnCrypto = display.newText(grpUI,"Crypto",_CX,height,font,50) 
    btnCrypto:addEventListener("touch",selectScene)
    btnCrypto.alpha = 0
    btnCrypto:setFillColor(0,0,1)

    btnThGraph = display.newText(grpUI,"Th Graph",_CX,height*5,font,50) 
    btnThGraph:addEventListener("touch",selectScene)
    btnThGraph.alpha = 0
    btnThGraph:setFillColor(0,0,1)

    btnBack = display.newText(grpUI,"Retour",_CX,height*6,font,40)
    btnBack:addEventListener("touch",popOutGameButtons)
    btnBack.alpha = 0

    btnPlay = display.newText(grpUI,"Jouer",0,0,font,50)
    btnPlay:setFillColor(0,0,1)
    if userData.id == nil then
        btnRegister = display.newText(grpUI,"Inscription",_CX,_CY,font,40)
        btnRegister:setFillColor(0,0,1)
        btnLogin = display.newText(grpUI,"Connexion",_CX,_CY+50,font,40)
        btnLogin:setFillColor(0,0,1)
        btnRegister:addEventListener("touch",selectScene)
        btnLogin:addEventListener("touch",selectScene)
        btnPlay.x = _CX
        btnPlay.y = _CY + 100
        currentAccount.text = "Non connecté"
        currentAccount:setFillColor(1,0,0)
    else
        btnLogout = display.newText(grpUI,"Logout",_CX,_CY+50,font,35)
        btnLogout:setFillColor(1,0,0)
        btnLogout:addEventListener("touch",logout)
        currentAccount.text = "Votre ID: "..userData.id
        currentAccount:setFillColor(0,1,1)
        btnPlay.x = _CX
        btnPlay.y = _CY
    end

    -- Check Login
    if userData.faded == 0 then
        whiteFade = display.newRect(grpWorld,0,0,display.contentHeight*2,display.contentHeight*2)
        whiteFade:setFillColor(1,1,1)
        whiteFadeRemove()
        slideDownBg()
        rotateLogo()
    elseif userData.faded == 1 then
        slideDownBg()
        logo.alpha = 0
        rotateLogo()
    elseif userData.faded == 2 then
        if userData.id == nil then
            popButtons()
        else
            popButtonsLoggedIn()
        end
        bg.x = 0
        bg.y = -(960*(1+display.contentHeight/960) - display.contentHeight)
    end

    --if userData.id == nil then
    --    currentAccount:setFillColor(1,0,0)
    --    currentAccount.text = "Non connecté"
    --else
    --    currentAccount:setFillColor(0,1,1)
    --    currentAccount.text = userData.id
    --end
end

-- show()
function scene:show(event)
    if(event.phase == "will") then
    elseif(event.phase == "did") then
    end
end

-- hide()
function scene:hide(event)
    if(event.phase == "will") then
    elseif(event.phase == "did") then
    end
end

-- destroy()
function scene:destroy(event)
    print("Destroyed : menu")
    btnWebpg:removeEventListener("touch",selectScene)
    btnThSig:removeEventListener("touch",selectScene)
    if userData.id == nil then
        btnLogin:removeEventListener("touch",selectScene)
        btnRegister:removeEventListener("touch",selectScene)
    else
        btnLogout:removeEventListener("touch",logout)
    end
    grpUI:removeSelf()
    grpWorld:removeSelf()
    grpMain:removeSelf()
end

-- -----------------------------------------
-- Scene event functions listeners
-- -----------------------------------------
scene:addEventListener("create",scene)
scene:addEventListener("show",scene)
scene:addEventListener("hide",scene)
scene:addEventListener("destroy",scene)
-- -----------------------------------------

return scene