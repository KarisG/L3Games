--------------------------------------------
-- Import
--------------------------------------------

local composer = require("composer")
local relayout = require("relayout")
local animation = require("animation")
local userData = require("userData")
local http = require("socket.http")
http.TIMEOUT = 3
local ltn12 = require("ltn12")

local reqbody
local respbody = {}

-- -----------------------------------------
-- Variables
-- -----------------------------------------

-- layout
local _W, _H, _CX, _CY = relayout._W, relayout._H, relayout._CX, relayout._CY

-- Scene
local scene = composer.newScene()

-- Groups
local grpMain
local grpWorld
local grpUI

-- Background
local bg

-- Buttons
local submit

-- Text Fields
local email = ""
local password = ""
local emailField
local passwordField

-- Labels
local emailLabel
local passwordLabel
local responseLabel
local font

-- Back
local returnToMenu

-- -----------------------------------------
-- Functions
-- -----------------------------------------


local function textListener(event)
    if event.phase == "editing" then
        if event.target == emailField then
            email = emailField.text
        elseif event.target == passwordField then
            password  = passwordField.text
        end
    end
end

-- Automatically login user if register is successful
local function sendDataLogin()
    reqbody = "email="..email.."&password="..password
    respbody = {}
    local result, respcode, respheaders,respstatus = http.request {
        method = "POST",
        url = "http://127.0.0.1:5000/login",
        source = ltn12.source.string(reqbody),
        headers = {
            ["content-type"] = "application/x-www-form-urlencoded",
            ["content-length"] = tostring(#reqbody)
        },
        body = reqbody,
        sink = ltn12.sink.table(respbody)
    }
    responseLabel.text = respbody[1]
    if respbody[1] == "1" then
        respbody = {}
        local result, respcode, respheaders,respstatus = http.request {
            method = "GET",
            url = "http://127.0.0.1:5000/me",
            sink = ltn12.sink.table(respbody)
        }
        userData.id = tonumber(respbody[1])
        slideLeftBg()
    else
        responseLabel:setFillColor(1,0,0)
        responseLabel.text = "Echec"
    end
end

local function sendData()
    reqbody = "email="..email.."&password="..password
    respbody = {}
    local result, respcode, respheaders,respstatus = http.request {
        method = "POST",
        url = "http://127.0.0.1:5000/register",
        source = ltn12.source.string(reqbody),
        headers = {
            ["content-type"] = "application/x-www-form-urlencoded",
            ["content-length"] = tostring(#reqbody)
        },
        body = reqbody,
        sink = ltn12.sink.table(respbody)
    }
    if respbody[1] == "1" then
        sendDataLogin()
    else
        responseLabel:setFillColor(1,0,0)
        responseLabel.text = "ECHEC"
    end
    
end

local function backToMenu(event)
    if event.phase == "began" then
        slideLeftBg()
    end
end

local function updateLabel(event)
    if event.phase == "began" then
        responseLabel.text = "Waiting..."
        send()
    end
end

function showFields()
    emailField = native.newTextField(display.contentCenterX,display.contentHeight*4/10,display.contentWidth*4/5,50)
    passwordField = native.newTextField(display.contentCenterX,display.contentHeight*6/10,display.contentWidth*4/5,50)
    grpUI:insert(emailField)
    grpUI:insert(passwordField)
    emailField:addEventListener('userInput',textListener)
    passwordField:addEventListener('userInput',textListener)
    returnToMenu:addEventListener('touch',backToMenu)
    submit:addEventListener('touch',updateLabel)
    popButtons()
end
-- -----------------------------------------
-- Animations
-- -----------------------------------------

function send()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime =  0,
                tween = { responseLabel,
                    { alpha = 0.99 }, 
                    { 
                        time = 1000,
                        onComplete = function()
                            sendData()
                        end,
                    }
                }   
            }
        },
    })
    newTimeline:resume()
end

function slideRightBg()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 0,
                tween = { bg,
                    { x = -(640*(1+display.contentWidth/640) - display.contentWidth)},
                    {
                        time = 1000,
                        onComplete = function()
                            showFields()
                        end,
                    }
                }
            }
        },
    })
    newTimeline:resume()
end

function slideLeftBg()
    grpUI.alpha = 0
    emailField:removeEventListener('userInput',textListener)
    passwordField:removeEventListener('userInput',textListener)
    emailField:removeSelf()
    passwordField:removeSelf()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 0,
                tween = { bg,
                    { x = 0},
                    {
                        time = 1000,
                        onComplete = function()
                            composer.gotoScene("scenes.menu")
                        end,
                    }
                }
            }
        },
    })
    newTimeline:resume()
end

function popButtons()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 0,
                tween = { grpUI,
                    { alpha = 1 },
                    {
                        time = 500,
                    }
                }
            },
            {
                startTime = 0,
                tween = { submit,
                    { xScale = 0, yScale = 0},
                    {
                        time = 1,
                    }
                }
            },
            {
                startTime = 0,
                tween = { returnToMenu,
                    { xScale = 0.01, yScale = 0.01},
                    {
                        time = 1,
                    }
                }
            },
            {
                startTime = 50,
                tween = { submit,
                    { xScale = 1.2, yScale = 1.2},
                    {
                        time = 400,
                    }
                }
            },
            {
                startTime = 50,
                tween = { returnToMenu,
                    { xScale = 1.2, yScale = 1.2},
                    {
                        time = 400,
                    }
                }
            },
            {
                startTime = 450,
                tween = { returnToMenu,
                    { xScale = 1, yScale = 1},
                    {
                        time = 200,
                    }
                },
            },
            {
                startTime = 450,
                tween = { returnToMenu,
                    { xScale = 1, yScale = 1},
                    {
                        time = 200,
                    }
                }
            },
        },
    })
    newTimeline:resume()
end

-- -----------------------------------------
-- Scene event functions
-- -----------------------------------------

-- create()
function scene:create(event)
    print("scene:create - register")
    -- Create main group and insert
    grpMain = display.newGroup()
    grpUI = display.newGroup()
    grpWorld = display.newGroup()
    grpUI.alpha = 0
    grpMain:insert(grpWorld)
    grpMain:insert(grpUI)
    self.view:insert(grpMain)

    font = "assets/fonts/GAMERIA.ttf"
    -- Background
    bg = display.newImageRect(grpWorld,"assets/images/bg.jpg",640*(1+display.contentWidth/640),960*(1+display.contentHeight/960))
    bg.anchorX = 0
    bg.anchorY = 0
    bg.x = 0
    bg.y = -(960*(1+display.contentHeight/960) - display.contentHeight)
    slideRightBg()

    -- Buttons
    submit = display.newText(grpUI,"S'inscrire",display.contentCenterX,display.contentHeight*8/10,font,40)
    submit:setFillColor(0.90,0.70,0.21)
    returnToMenu = display.newText(grpUI,"Retour",display.contentCenterX,display.contentHeight*9/10,font,40)
    returnToMenu:setFillColor(0.90,0.70,0.21)

    -- Text Fields
    responseLabel = display.newText(grpUI,"Inscription",display.contentCenterX,display.contentHeight*2/10,font,50)
    responseLabel:setFillColor(0,0,1)
    emailLabel = display.newText(grpUI,"Email",display.contentCenterX,display.contentHeight*3/10,font,40)
    passwordLabel = display.newText(grpUI,"Mot de passe",display.contentCenterX,display.contentHeight*5/10,font,40)
end

-- show()
function scene:show(event)
    if(event.phase == "will") then
    elseif(event.phase == "did") then
    end
end

-- hide()
function scene:hide(event)
    if(event.phase == "will") then
    elseif(event.phase == "did") then
    end
end

-- destroy()
function scene:destroy(event)
    submit:removeEventListener('touch',sendData)
    returnToMenu:removeEventListener('touch',backToMenu)
    grpUI:removeSelf()
    grpWorld:removeSelf()
    grpMain:removeSelf()
end

-- -----------------------------------------
-- Scene event functions listeners
-- -----------------------------------------
scene:addEventListener("create",scene)
scene:addEventListener("show",scene)
scene:addEventListener("hide",scene)
scene:addEventListener("destroy",scene)
-- -----------------------------------------

return scene