--------------------------------------------
-- Import
--------------------------------------------

local composer = require("composer")
local animation = require("animation")

-- -----------------------------------------
-- Variables
-- -----------------------------------------
-- Scene
local scene = composer.newScene()

-- Groups
local grpMain
local grpEfrei

-- Background
local bg
local whiteScreen

-- Efrei
local efrei

-- Logo
local logoTitle
local logoDisplay = {}

-- -----------------------------------------
-- Functions
-- -----------------------------------------

function addOneLetter(index)
    if index+1 <= #logoDisplay then
        underDialogWrite(index+1)
    end
end

-- -----------------------------------------
-- Animations
-- -----------------------------------------

function timerToDeath()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 2000,
                tween = { whiteScreen,
                    { alpha = 1 },
                    {
                        time = 1000,
                        onComplete = function()
                            composer.removeScene("scenes.efrei")
                            composer.gotoScene("scenes.menu")
                        end
                    }
                }
            },
        },
    })
    newTimeline:resume()
end

function showEfrei()
    local newTimeline = animation.newTimeline( {
        tweens = {
            {
                startTime = 0,
                tween = { grpEfrei,
                    { alpha = 1 },
                    {
                        time = 1000,
                        onComplete = function()
                            timerToDeath()
                        end
                    }
                }
            },
        },
    })
    newTimeline:resume()
end

function underDialogWrite(index)
    local newTimeline
    if index < 18 then
        newTimeline = animation.newTimeline( {
            tweens = {
                {
                    startTime = 0,
                    tween = { logoDisplay[index],
                        { alpha = 1, y = display.contentCenterY*1.5+10 },
                        {
                            time = 100,
                            onComplete = function()
                                addOneLetter(index)
                                if index == 2 then
                                    showEfrei()
                                end
                            end,
                        }
                    }
                },
                {
                    startTime = 100,
                    tween = { logoDisplay[index],
                        { alpha = 1,y = display.contentCenterY*1.5 },
                        {
                            time = 50,
                        }
                    }
                },
            },
        })
    elseif index < 20 then
        newTimeline = animation.newTimeline( {
            tweens = {
                {
                    startTime = 0,
                    tween = { logoDisplay[index],
                        { alpha = 1,y = display.contentCenterY*1.5+40 },
                        {
                            time = 100,
                            onComplete = function()
                                addOneLetter(index)
                            end,
                        }
                    }
                },
                {
                    startTime = 99,
                    tween = { logoDisplay[index],
                        { alpha = 1,y = display.contentCenterY*1.5+30 },
                        {
                            time = 50,
                        }
                    }
                },
            },
        })
    else
        newTimeline = animation.newTimeline( {
            tweens = {
                {
                    startTime = 0,
                    tween = { logoDisplay[index],
                        { alpha = 1,y = display.contentCenterY*1.5+70 },
                        {
                            time = 100,
                            onComplete = function()
                                addOneLetter(index)
                            end,
                        }
                    }
                },
                {
                    startTime = 99,
                    tween = { logoDisplay[index],
                        { alpha = 1,y = display.contentCenterY*1.5+60 },
                        {
                            time = 50,
                        }
                    }
                },
            },
        })
    end
    newTimeline:resume()
end

-- -----------------------------------------
-- Scene event functions
-- -----------------------------------------

-- create()
function scene:create(event)
    print("scene:create - efrei")
    -- Create main group and insert
    grpMain = display.newGroup()
    grpEfrei = display.newGroup()
    --grpEfrei.alpha = 0
    self.view:insert(grpMain)
    -- Insert objects to grpMain here
    --Background
    
    bg = display.newRect(grpMain,0,0,display.contentWidth*2,display.contentHeight*2)
    grpMain:insert(grpEfrei)


    -- Efrei
    efrei = display.newImageRect(grpEfrei,"assets/images/efrei.png",250,375)
    efrei.x = display.contentCenterX
    if display.contentCenterY >= 320 then
        efrei.y = display.contentCenterY
    else
        efrei.y = display.contentCenterY/1.5
    end
    
    -- Logo
    logoTitle = {'E','c','o','l','e','d','\'','i','n','g','é','n','i','e','u','r','s','d','u','n','u','m','é','r','i','q','u','e'}
    for i=1,#logoTitle,1 do
        local newCharacter = display.newText(grpEfrei,logoTitle[i],0,0,"assets/fonts/fonty.otf",30)
        if i<4 then --Ecole
            newCharacter.x = display.contentCenterX/3+15*(i-1)+2
        elseif i<18 then --d'ingénieurs
            if(i==5)then
                newCharacter.x = display.contentCenterX/3 +  15*(i-1) - 2
            elseif(i==6) then
                newCharacter.x = display.contentCenterX/3 + 10 + 15*(i-1)
            elseif(i==7) then
                newCharacter.x = display.contentCenterX/3 + 10 + 14.5*(i-1)
            elseif(i<9)then
                newCharacter.x = display.contentCenterX/3 + 15*(i-1)
            elseif(i==10)then
                newCharacter.x = display.contentCenterX/3 + 15*(i-1)
            elseif(i==11)then
                newCharacter.x = display.contentCenterX/3 +  15*(i-1) + 2
            elseif(i==12)then
                newCharacter.x = display.contentCenterX/3 +  15*(i-1) + 4
            elseif(i==13)then
                newCharacter.x = display.contentCenterX/3 +  15*(i-1) + 1
            elseif(i==17)then
                newCharacter.x = display.contentCenterX/3 -5 +  15*(i-1) 
            else
                newCharacter.x = display.contentCenterX/3 -2 +  15*(i-1)
            end
        elseif i<20 then --du
            newCharacter.x = display.contentCenterX/3 + 15*(i-11) + 10 
        elseif i<22 then --nu
            newCharacter.x = display.contentCenterX/3 + 15.5*(i-16) + 5
        elseif i<23 then --m
            newCharacter.x = display.contentCenterX/3 +7+ 15*(i-16) + 5
        elseif i<24 then --é
            newCharacter.x = display.contentCenterX/3 +12+ 15*(i-16) + 5
        elseif i<25 then --r
            newCharacter.x = display.contentCenterX/3 +12+ 15*(i-16) + 3
        elseif i<26 then --i 
            newCharacter.x = display.contentCenterX/3 +9+ 15*(i-16)
        else --que
            newCharacter.x = display.contentCenterX/3 +6+ 15*(i-16)
        end
        newCharacter:setFillColor(0.58,0.38,0.608)
        newCharacter.alpha = 0
        logoDisplay[#logoDisplay+1] = newCharacter
    end

    whiteScreen =  display.newRect(grpMain,0,0,display.contentWidth*2,display.contentHeight*2)
    whiteScreen:setFillColor(1,1,1)
    whiteScreen.alpha = 0
    ---
    underDialogWrite(1)
end

-- show()
function scene:show(event)
    if(event.phase == "will") then
    elseif(event.phase == "did") then
    end
end

-- hide()
function scene:hide(event)
    if(event.phase == "will") then
    elseif(event.phase == "did") then
    end
end

-- destroy()
function scene:destroy(event)
    grpEfrei:removeSelf()
    grpMain:removeSelf()
    self.view:removeSelf()
end

-- -----------------------------------------
-- Scene event functions listeners
-- -----------------------------------------
scene:addEventListener("create",scene)
scene:addEventListener("show",scene)
scene:addEventListener("hide",scene)
scene:addEventListener("destroy",scene)
-- -----------------------------------------

return scene