-- -----------------------------------------------------------------------------------
-- Import
-- -----------------------------------------------------------------------------------

local composer = require("composer")
local relayout = require("relayout")


-- -----------------------------------------------------------------------------------
-- Set variables
-- -----------------------------------------------------------------------------------

-- Layout
local _W, _H, _CX, _CY = relayout._W, relayout._H, relayout._CX, relayout._CY

-- Scene
local scene = composer.newScene()

-- Groups
local grpMain


-- -----------------------------------------------------------------------------------
-- Scene event functions
-- -----------------------------------------------------------------------------------

-- create()
function scene:create( event )
  print("scene:create - aide")

  -- Create main group and insert to scene
  grpMain = display.newGroup()

  self.view:insert(grpMain)

  -- Insert objects to grpMain here

  local bg = display.newImageRect("TheorieSig/Picture/background.png", _W, _H)
  bg.x = _CX
  bg.y = _CY
  grpMain:insert(bg)
  --
  local Retour = display.newImageRect("TheorieSig/Picture/retour.jpg", 50, 50 )
  Retour.x = 25
  Retour.y = 25
  grpMain:insert(Retour)

  local Text =  display.newText("Pour vous aider à déterminer les\n graphes, voici les graphiques\n des fonctions caractéristiques !", _CX, _H*(3/20) ,native.systemFont, 16 )
  Text.width = _W
  Text:setFillColor( 0, 0, 0 )
  grpMain:insert(Text)

  local f1 = display.newImageRect("TheorieSig/Picture/Aide/AideFonction1.PNG", 187,48 )
  f1.x = _CX
  f1.y = _H*(5.5/20)
  grpMain:insert(f1)

  local f2 = display.newImageRect("TheorieSig/Picture/Aide/AideFonction2.PNG", 159,57)
  f2.x = _CX
  f2.y = _H*(8.5/20)
  grpMain:insert(f2)

  local f3 = display.newImageRect("TheorieSig/Picture/Aide/AideFonction3.PNG", 251, 111 )
  f3.x = _CX
  f3.y = _H*(11.5/20)
  grpMain:insert(f3)

  local f4 = display.newImageRect("TheorieSig/Picture/Aide/AideFonction4.PNG", 265,68 )
  f4.x = _CX
  f4.y = _H*(14.5/20)
  grpMain:insert(f4)

  local f5 = display.newImageRect("TheorieSig/Picture/Aide/AideFonction5.PNG", 260,97 )
  f5.x = _CX
  f5.y = _H*(17.5/20)
  grpMain:insert(f5)

  f1:addEventListener("tap", function() 
    composer.gotoScene("TheorieSig.scenes.aideF1")
  end)

  f2:addEventListener("tap", function() 
    composer.gotoScene("TheorieSig.scenes.aideF2")
  end)

  f3:addEventListener("tap", function() 
    composer.gotoScene("TheorieSig.scenes.aideF3")
  end)

  f4:addEventListener("tap", function() 
    composer.gotoScene("TheorieSig.scenes.aideF4")
  end)

  f5:addEventListener("tap", function() 
    composer.gotoScene("TheorieSig.scenes.aideF5")
  end)

  Retour:addEventListener("tap", function() 
    composer.gotoScene("TheorieSig.scenes.menu")
  end)  
end



-- show()
function scene:show( event )
  if ( event.phase == "will" ) then
  elseif ( event.phase == "did" ) then
  end
end



-- hide()
function scene:hide( event )
  if ( event.phase == "will" ) then
  elseif ( event.phase == "did" ) then
  end
end



-- destroy()
function scene:destroy(event)
  if event.phase == "will" then
  end
end



-- -----------------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- -----------------------------------------------------------------------------------

return scene
