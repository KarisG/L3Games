-- -----------------------------------------------------------------------------------
-- Import
-- -----------------------------------------------------------------------------------

local composer = require("composer")
local relayout = require("relayout")


-- -----------------------------------------------------------------------------------
-- Set variables
-- -----------------------------------------------------------------------------------

-- Layout
local _W, _H, _CX, _CY = relayout._W, relayout._H, relayout._CX, relayout._CY

-- Scene
local scene = composer.newScene()

-- Groups
local grpMain


-- -----------------------------------------------------------------------------------
-- Scene event functions
-- -----------------------------------------------------------------------------------

-- create()
function scene:create( event )
  print("scene:create - aideF5")

  -- Create main group and insert to scene
  grpMain = display.newGroup()

  self.view:insert(grpMain)

  -- Insert objects to grpMain here

  local bg = display.newImageRect("TheorieSig/Picture/background.png", _W, _H)
  bg.x = _CX
  bg.y = _CY
  grpMain:insert(bg)
  --
  local Retour = display.newImageRect("TheorieSig/Picture/retour.jpg", 50, 50 )
  Retour.x = 25
  Retour.y = 25
  grpMain:insert(Retour)

  local Text =  display.newText("Diagramme de Bode de la fonction :", _CX, _H*(2/20) ,native.systemFont, 16 )
  Text.width = _W
  Text:setFillColor( 0, 0, 0 )
  grpMain:insert(Text)

  local f1 = display.newImageRect("TheorieSig/Picture/Aide/AideFonction5.PNG", (_H)*(3/20), (_H)*(1.5/20) )
  f1.x = _CX
  f1.y = _H*(3.5/20)
  grpMain:insert(f1)

  local amplitude = display.newImageRect("TheorieSig/Picture/Aide/AideAmplitude5.PNG", (_W)*(3/4), (_H)*6/20 )
  amplitude.x = _CX
  amplitude.y = _H*(7.5/20)
  grpMain:insert(amplitude)

  local phase = display.newImageRect("TheorieSig/Picture/Aide/AidePhase5.PNG", (_W)*(3/4), (_H)*6/20 )
  phase.x = _CX
  phase.y = _H*(15/20)
  grpMain:insert(phase)

  Retour:addEventListener("tap", function() 
    composer.gotoScene("TheorieSig.scenes.aide")
  end)
  
end



-- show()
function scene:show( event )
  if ( event.phase == "will" ) then
  elseif ( event.phase == "did" ) then
  end
end



-- hide()
function scene:hide( event )
  if ( event.phase == "will" ) then
  elseif ( event.phase == "did" ) then
  end
end



-- destroy()
function scene:destroy(event)
  if event.phase == "will" then
  end
end



-- -----------------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- -----------------------------------------------------------------------------------

return scene
