-- -----------------------------------------------------------------------------------
-- Import
-- -----------------------------------------------------------------------------------

local composer = require("composer")
local relayout = require("relayout")
local utilities = require("TheorieSig.utilities")



-- -----------------------------------------------------------------------------------
-- Set variables
-- -----------------------------------------------------------------------------------

-- Layout
local _W, _H, _CX, _CY = relayout._W, relayout._H, relayout._CX, relayout._CY

-- Scene
local scene = composer.newScene()

-- Groups
local grpMain

local maxScore = 11
local bg
local AmplitudeIcone
local PhaseIcone
local Aide
local lblScoreAmplitude
local lblScorePhase
local Retour

function returnMenu(event)
  if event.phase == "began" then
    composer.gotoScene("scenes.menu")
  end
end

function goAmplitude(event)
  if event.phase == "began" then
    composer.gotoScene("TheorieSig.scenes.amplitude")
  end
end

function goPhase(event)
  if event.phase == "began" then
    composer.gotoScene("TheorieSig.scenes.phase")
  end
end

function goAide(event)
  if event.phase == "began" then
    composer.gotoScene("TheorieSig.scenes.aide")
  end
end
-- -----------------------------------------------------------------------------------
-- Scene event functions
-- -----------------------------------------------------------------------------------

-- create()
function scene:create( event )
  print("scene:create - menu")

  -- Create main group and insert to scene
  grpMain = display.newGroup()

  self.view:insert(grpMain)

  -- Insert objects to grpMain here

  bg = display.newImageRect("TheorieSig/Picture/background.png", _W, _H)
  bg.x = _CX
  bg.y = _CY
  grpMain:insert(bg)

  --
  AmplitudeIcone = display.newImageRect("TheorieSig/Picture/AmplitudeIcone.png", (_H)*(5/20), (_H)*(5/20) )
  AmplitudeIcone.x = _CX
  AmplitudeIcone.y = _H*(4.5/20)
  grpMain:insert(AmplitudeIcone)
  
  PhaseIcone = display.newImageRect("TheorieSig/Picture/PhaseIcone.png", (_H)*(5/20), (_H)*(5/20) )
  PhaseIcone.x = _CX
  PhaseIcone.y = _H*(10.5/20)
  grpMain:insert(PhaseIcone)
  
  Aide = display.newImageRect("TheorieSig/Picture/Aide.png", (_H)*(5/20), (_H)*(5/20) )
  Aide.x = _CX
  Aide.y = _H*(16.5/20)
  grpMain:insert(Aide)

  lblScoreAmplitude =  display.newText( "Meilleur score: "..utilities:getHighScoreAmplitude(), _CX, _H*(1.5/20), native.systemFont, 30 )
  print(utilities:getHighScoreAmplitude())
  lblScoreAmplitude:setFillColor( 0, 0, 0 )
  if(utilities:getHighScoreAmplitude() == maxScore) then
    lblScoreAmplitude:setFillColor(127,0,255)
  end
  grpMain:insert(lblScoreAmplitude)

  lblScorePhase =  display.newText( "Meilleur score: "..utilities:getHighScorePhase(), _CX, _H*(7.5/20), native.systemFont, 30 )
  lblScorePhase:setFillColor( 0, 0, 0 )
  if(utilities:getHighScorePhase() == maxScore) then
    lblScorePhase:setFillColor(127,0,255)
  end
  grpMain:insert(lblScorePhase)

  Retour = display.newImageRect("TheorieSig/Picture/retour.jpg", 50, 50 )
  Retour.x = 25
  Retour.y = 25
  grpMain:insert(Retour)

  Retour:addEventListener("touch",returnMenu)
  AmplitudeIcone:addEventListener("touch",goAmplitude)
  PhaseIcone:addEventListener("touch",goPhase)
  Aide:addEventListener("touch",goAide)
end



-- show()
function scene:show( event )
  if ( event.phase == "will" ) then
  elseif ( event.phase == "did" ) then
  end
end



-- hide()
function scene:hide( event )
  if ( event.phase == "will" ) then
  elseif ( event.phase == "did" ) then
  end
end



-- destroy()
function scene:destroy(event)
  Retour:removeEventListener("touch",returnMenu) 
  AmplitudeIcone:removeEventListener("touch",goAmplitude)
  PhaseIcone:removeEventListener("touch",goPhase)
  Aide:removeEventListener("touch",goAide)
  grpMain:removeSelf()
end


-- -----------------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- -----------------------------------------------------------------------------------

return scene
