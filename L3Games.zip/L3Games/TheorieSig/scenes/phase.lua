-- -----------------------------------------------------------------------------------
-- Import
-- -----------------------------------------------------------------------------------

local composer = require("composer")
local relayout = require("relayout")
local utilities = require("TheorieSig.utilities")

-- Seed the random number generator
math.randomseed( os.time() )

-- -----------------------------------------------------------------------------------
-- Set variables
-- -----------------------------------------------------------------------------------

-- Layout
local _W, _H, _CX, _CY = relayout._W, relayout._H, relayout._CX, relayout._CY

-- Scene
local scene = composer.newScene()

-- Groups
local grpMain
local BodeGroup
local uiGroup


-- Variables


fonctions = {}
local lblScore
local fonction      --fonction en cours d'affichage
local bodeA,bodeB,bodeC,bodeD --graphes en cours d'affichage
local questionBode = 0
local score = 0


--declaration des fonctions
local question



local function updateText()
    lblScore.text = "Score: ".. score
end

local function endBode()
    utilities:setHighScorePhase(score)
    if(#fonctions > 0) then
        print("Défaite !")
    end
    score = 0
    display.remove(fonction)
    display.remove(bodeA)
    display.remove(bodeB)
    display.remove(bodeC)
    display.remove(bodeD)
    table.remove(fonctions)
    composer.gotoScene("TheorieSig.scenes.menu")
end

local function win()
    score = score + 1
    updateText()
    if(#fonctions < 1) then
        print("Victoire !")
        endBode()
    else
        question()
    end
end


local function reponse()
    
    local box = display.newRect(uiGroup,_W-(_W*(18/10)),_H+(_W*(18/10)),_W*(9/10),_W*(9/10))
    transition.to(box, {time = 1000, x = _CX, y = _CY})
    bodeA:removeEventListener("tap",reponse)
    bodeB:removeEventListener("tap",reponse)
    bodeC:removeEventListener("tap",reponse)
    bodeD:removeEventListener("tap",reponse)
    bodeA:removeEventListener("tap",win)
    bodeB:removeEventListener("tap",win)
    bodeC:removeEventListener("tap",win)
    bodeD:removeEventListener("tap",win)
    box:addEventListener("tap",endBode)

    local t1 = display.newText(uiGroup,"Vous avez sélectionnez la mauvaise réponse!",_W-(_W*(18/10)),_H+(_W*(18/10)),native.systemFont,15)
    t1:setFillColor(0,0,0)
    local t2 = display.newText(uiGroup,"Le graphique correspondant à la fonction était:",_W-(_W*(18/10)),_H+(_W*(18/10)),native.systemFont,15)
    t2:setFillColor(0,0,0)
    local graphe = display.newImageRect( uiGroup, "TheorieSig/Picture/Phase/Phase"..questionBode..".PNG", _W*(9/10), _W*(9/10)-100 )
    graphe.x = _W-(_W*(18/10))
    graphe.y = _H+(_W*(18/10))
    local ok = display.newText(uiGroup,"Si vous ne comprenez pas, allez dans 'Aide'",_W-(_W*(18/10)),_H+(_W*(18/10)),native.systemFont,15)
    ok:setFillColor(0,0,0)

    transition.to(t1, {time = 1000, x = _CX, y = _CY-(_W*(9/10)*(1/2))+20})
    transition.to(t2, {time = 1000, x = _CX, y = _CY-(_W*(9/10)*(1/2))+40})
    transition.to(graphe, {time = 1000, x = _CX, y = _CY})
    transition.to(ok, {time = 1000, x = _CX, y = _CY+(_W*(9/10)*(1/2))-20})
end

question = function()
    display.remove(fonction)
    display.remove(bodeA)
    display.remove(bodeB)
    display.remove(bodeC)
    display.remove(bodeD)  
    if(fonctions == nil) then
        endBode()
    end
    local n = 0
    if(#fonctions == 1) then
        n = 1
    else
        repeat
            n = math.random(1,(#fonctions))
        until (fonctions[n] ~= nil)
    end
    questionBode = fonctions[n]
    fonction = display.newImageRect( BodeGroup, "TheorieSig/Picture/Fonction/fonction"..questionBode..".PNG", (_H)*(3/20), (_H)*(1.5/20) )
    fonction.x = _W*(1/4)
    fonction.y = (_H)*(2/20)
    --position de la bonne réponse
    local temp = math.random(1,4)
    --les trois réponses aléatoires fausses
    local f1,f2,f3
    
    repeat
        f1 = math.random(1,11)
    until (f1 ~= questionBode)
    repeat
        f2 = math.random(1,11)
    until (f2 ~= questionBode) and (f2 ~= f1)
    repeat
        f3 = math.random(1,11)
    until (f3 ~= questionBode) and (f3 ~= f1) and (f3 ~= f2)


    for i = 1,4 do

        if (i == 1) then
            if(i == temp) then
                bodeA = display.newImageRect( BodeGroup, "TheorieSig/Picture/Phase/Phase"..questionBode..".PNG", (_W)*1/2, (_H)*4/20 )
                bodeA:addEventListener("tap",win)
            else
                bodeA = display.newImageRect( BodeGroup, "TheorieSig/Picture/Phase/Phase"..f1..".PNG", (_W)*1/2, (_H)*4/20 )
                bodeA:addEventListener("tap",reponse)
            end
            bodeA.x = _CX
            bodeA.y = (_H)*(5/20)
        elseif (i == 2) then
            if(i == temp) then
                bodeB = display.newImageRect( BodeGroup, "TheorieSig/Picture/Phase/Phase"..questionBode..".PNG", (_W)*1/2, (_H)*4/20)
                bodeB:addEventListener("tap",win)
            else
                if(temp<i) then
                    bodeB = display.newImageRect( BodeGroup, "TheorieSig/Picture/Phase/Phase"..f1..".PNG", (_W)*1/2, (_H)*4/20 )
                    bodeB:addEventListener("tap",reponse)
                else
                    bodeB = display.newImageRect( BodeGroup, "TheorieSig/Picture/Phase/Phase"..f2..".PNG", (_W)*1/2, (_H)*4/20 )
                    bodeB:addEventListener("tap",reponse)
                end                
            end
            bodeB.x = _CX
            bodeB.y = (_H)*(9/20)+5
        elseif (i == 3) then
            if(i == temp) then
                bodeC = display.newImageRect( BodeGroup, "TheorieSig/Picture/Phase/Phase"..questionBode..".PNG", (_W)*1/2, (_H)*4/20 )
                bodeC:addEventListener("tap",win)
            else
                if(temp<i) then
                    bodeC = display.newImageRect( BodeGroup, "TheorieSig/Picture/Phase/Phase"..f2..".PNG",(_W)*1/2, (_H)*4/20 )
                    bodeC:addEventListener("tap",reponse)
                else
                    bodeC = display.newImageRect( BodeGroup, "TheorieSig/Picture/Phase/Phase"..f3..".PNG", (_W)*1/2, (_H)*4/20 )
                    bodeC:addEventListener("tap",reponse)
                end  
            end
            bodeC.x = _CX
            bodeC.y = (_H)*(13/20)+10
        else
            if(i == temp) then
                bodeD = display.newImageRect( BodeGroup, "TheorieSig/Picture/Phase/Phase"..questionBode..".PNG", (_W)*1/2, (_H)*4/20 )
                bodeD:addEventListener("tap",win)
            else
                bodeD = display.newImageRect( BodeGroup, "TheorieSig/Picture/Phase/Phase"..f3..".PNG", (_W)*1/2, (_H)*4/20 )
                bodeD:addEventListener("tap",reponse)  
            end
            bodeD.x = _CX
            bodeD.y = (_H)*(17/20)+15
        end

    end
    table.remove(fonctions,n)
end


-- -----------------------------------------------------------------------------------
-- Scene event functions
-- -----------------------------------------------------------------------------------

-- create()
function scene:create( event )
    print("scene:create - phase")

    -- Create main group and insert to scene
    grpMain = display.newGroup()

    self.view:insert(grpMain)

    BodeGroup = display.newGroup()  -- Display group for the background image
    grpMain:insert(BodeGroup)

    uiGroup = display.newGroup()
    grpMain:insert(uiGroup)

    -- Insert objects to grpMain here

    -- Load the background
    local background = display.newImageRect( BodeGroup, "TheorieSig/Picture/background.png", _W, _H )
    background.x = _CX
    background.y = _CY

    --
    -- Score label

    lblScore = display.newText("Score: "..score, _W*(3/4), (_H)*(2/20), native.systemFont, 18)
    lblScore:setFillColor( 0, 0, 0 )
    uiGroup:insert(lblScore)

    --initialisation des 40 questions
    for i = 1, 11 do
        table.insert(fonctions,i)
    end
    question()
end



-- show()
function scene:show( event )
  if ( event.phase == "will" ) then
  elseif ( event.phase == "did" ) then
  end
end



-- hide()
function scene:hide( event )
  if ( event.phase == "will" ) then
  elseif ( event.phase == "did" ) then
  end
end



-- destroy()
function scene:destroy(event)
  if event.phase == "will" then
    Runtime:removeEventListener("enterFrame", update)
    Runtime:removeEventListener("touch", touch)
  end
end



-- -----------------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- -----------------------------------------------------------------------------------

return scene
