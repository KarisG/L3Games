-- -----------------------------------------------------------------------------------
-- Create class and variables
-- -----------------------------------------------------------------------------------

local userData = require('userData')
local http = require("socket.http")
http.TIMEOUT = 5
local ltn12 = require("ltn12")

-- -----------------------------------------------------------------------------------
-- Create class and variables
-- -----------------------------------------------------------------------------------

local utilities = {}

-- -----------------------------------------------------------------------------------
-- Functions
-- -----------------------------------------------------------------------------------

local function updateDatabase(mode)
    local reqbody
    
    local respbody = {}
    if mode == "amp" then
        reqbody = "score="..userData.thsignalamp
        local result, respcode, respheaders,respstatus = http.request {
            method = "PUT",
            url = "http://127.0.0.1:5000/updatethsamp",
            source = ltn12.source.string(reqbody),
            headers = {
                ["content-type"] = "application/x-www-form-urlencoded",
                ["content-length"] = tostring(#reqbody)
            },
            body = reqbody,
            sink = ltn12.sink.table(respbody)
        }
    else 
        reqbody = "score="..userData.thsignalpha
        local result, respcode, respheaders,respstatus = http.request {
            method = "PUT",
            url = "http://127.0.0.1:5000/updatethspha",
            source = ltn12.source.string(reqbody),
            headers = {
                ["content-type"] = "application/x-www-form-urlencoded",
                ["content-length"] = tostring(#reqbody)
            },
            body = reqbody,
            sink = ltn12.sink.table(respbody)
        }
    end
end

-- -----------------------------------------------------------------------------------
-- Highscore
-- -----------------------------------------------------------------------------------

function utilities:getHighScoreAmplitude()
    return userData.thsignalamp
end

function utilities:getHighScorePhase()
    return userData.thsignalpha
end

function utilities:setHighScoreAmplitude(score)
    if score > userData.thsignalamp then
        userData.thsignalamp = score
        if userData.id ~= nil then
            updateDatabase("amp")
        end
        return true
    else
        return false
    end
end

function utilities:setHighScorePhase(score)
    if score > userData.thsignalpha then
        userData.thsignalpha = score
        if userData.id ~= nil then
            updateDatabase("pha")
        end
        return true
    else
        return false
    end
end



-- -----------------------------------------------------------------------------------
-- Return
-- -----------------------------------------------------------------------------------

return utilities
