local composer = require('composer')
local userData = require('userData')
userData.id = nil
userData.faded = 0
composer.recycleOnSceneChange = true
composer.gotoScene("scenes.efrei")